#include <stdio.h>
#include <stdarg.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <math.h>

#include <export.h>

#include <local_defs.h>
#include <user_defs.h>
#include <idf_defs.h>
#include <DbDefs.h>
#include <ret_codes.h>
#include <libbase_udf.h>
#include <PidfAnsi.h>
#include <PidfStr.h>
#include <PidfRets.h>
#include <libCfg.h>
#include <StrHier.h>
#include <dbf.h>

#include "udfdlm_defs.h"
#include "udfdlm_ansi.h"

/********************\
|* udfdlm_get_date  *|  convert [YYYY,DOY,millisec] to yy, doy, sec, nano
\********************/

void udfdlm_get_date( IDL_VPTR arg, int *yy, int *doy, int *sec, int *ns )
{
  /* Sanity checks: we must have an array of exactly two to six elements */

   if (arg->value.arr->dim[0] < 2)
      idl_barf("date arg must be [YYYY, DOY [,hr?,min?,sec?,msec?]]");

   if (arg->value.arr->dim[0] > 6)
      idl_barf("> 6 values in date arg; expected [YYYY,DOY,hh,mm,ss,msec]");

  /* YY is the first element, DOY is the second */

    *yy  = *((int*)arg->value.arr->data);
    *doy = *((int*)arg->value.arr->data + 1);

  /* Start off by assuming that seconds (and nano) are zero: start of day */

    *sec = *ns = 0;

  /* If further array elements are present, treat as hours/minutes/seconds */

    if (arg->value.arr->dim[0] > 2)		          /* Hours present?  */
       *sec += *((int*)arg->value.arr->data + 2) * 3600;  /* seconds/hour    */

    if (arg->value.arr->dim[0] > 3)		          /* Min present?    */
      *sec += *((int*)arg->value.arr->data + 3) * 60;     /* seconds/minute  */

    if (arg->value.arr->dim[0] > 4)		          /* Sec present?    */
      *sec += *((int*)arg->value.arr->data + 4);

    if (arg->value.arr->dim[0] > 5)		          /* Msec present?   */
      *ns = *((int*)arg->value.arr->data + 5) * 1E6;	  /* convert to nano */
}
