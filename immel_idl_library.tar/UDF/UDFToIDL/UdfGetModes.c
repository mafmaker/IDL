#include <stdio.h>
#include <stdarg.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <math.h>

#include <export.h>

#include <user_defs.h>
#include <DbDefs.h>
#include <ret_codes.h>
#include <libbase_udf.h>
#include <PidfAnsi.h>
#include <PidfStr.h>
#include <PidfRets.h>

#include "udfdlm_defs.h"
#include "udfdlm_ansi.h"

/********************************\
|* udfdlm_read_and_fill_struct  *|  With a filehandle, read & return one rec
\********************************/

void UdfGetModes( struct fh_cache *fh, ByTe_1 *Base)
{
   extern ByTe_1 Ext[];
   extern u_ByTe_2 Version;
   extern void *UDF;

   struct Pidf        *P;
   struct PidfUnit    *Pu;

   ByTe_2 I, tN;
   ByTe_2 rV;

   ByTe_1 *trac;

   P = (struct Pidf *)fh->PIDF;
   Pu = (struct PidfUnit *)P->Units;

   trac = Base + fh->Begs[7];
   for (I = 0; I < fh->TotMode; ++I) {
       tN = fh->mUnits[I];
       rV = convert_to_units(fh->Key, Ext, Version, UDF, MODE,
                             (ByTe_1)I, (ByTe_1)Pu[tN].NTbls, Pu[tN].Tbls, 
                             Pu[tN].Ops, (ReaL_4*)trac, 0, 0);
       if (rV != ALL_OKAY)
           udf_barf("convert_to_units", rV);
       trac += sizeof (ReaL_4);
   }
}
