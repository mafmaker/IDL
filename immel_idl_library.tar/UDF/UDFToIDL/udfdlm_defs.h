#ifndef __UDF_DLM_DEFS_H
#define __UDF_DLM_DEFS_H 1

#define MAX_TAG_LEN   80
#define MAX_TAGS      20
#define MAX_BEGS      15
#define MAX_UNITS    512
#define MAX_OPEN     100
#define FHANDLE_BASE 601

#define FG(a,b,c)					\
		if (FieldGetN(a,b,c) != SUCCESS)	\
		  idl_barf("db_get(%s)",b)

/*
** PAD() will add pad bytes to a pointer p until it hits the proper
**       alignment for l.  It is used when defining and filling in structs.
**
** Note carefully the definition and use of ALIGN_MASK.  This is for
** handling the varying needs of different architectures, some of which
** align doubles on a 4-byte boundary, others which do so on 8.  We
** can't just always pad to 8 -- we need to get it exactly right.
*/

#define PAD(p,l)							\
		while (((unsigned long)(p)) & ALIGN_MASK & ((l)-1))	\
		  ((unsigned long)(p))++

#define SECONDS_PER_DAY		(86400)
#define PROCEDURE void
#define FUNCTION  IDL_VPTR

#define UDF_TIME  -1

#define SCALAR  1
#define ARRAY   2
#define MATRIX  3

#endif  /* __UDF_DLM_DEFS_H */
