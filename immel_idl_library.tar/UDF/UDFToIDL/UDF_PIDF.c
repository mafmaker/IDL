#include <stdio.h>
#include <stdarg.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <math.h>

#include <export.h>

#include <local_defs.h>
#include <user_defs.h>
#include <idf_defs.h>
#include <DbDefs.h>
#include <ret_codes.h>
#include <libbase_udf.h>
#include <PidfAnsi.h>
#include <PidfStr.h>
#include <PidfRets.h>
#include <libCfg.h>
#include <StrHier.h>
#include <dbf.h>

#include "udfdlm_defs.h"
#include "udfdlm_ansi.h"

/**************\
|*  UDF_PIDF  *|  Given a key (see above), returns a "PIDF" structure
\**************/

FUNCTION UDF_PIDF(int Argc, IDL_VPTR Argv[], char *kw_unused)
{
  extern void  *PIDF;

  ByTe_2       rV;
  u_ByTe_4     Key;		/* Input argument: determined from UDF_KEY() */

  static IDL_EZ_ARG arg_struct[] = {
    /* Key, unsigned long */
    { IDL_EZ_DIM_MASK(0),
      IDL_TYP_B_SIMPLE,
      IDL_EZ_ACCESS_R,
      IDL_TYP_ULONG,
      0,
      0 }
  };

  /* Make sure we got the right number of arguments */
  if (Argc != 1)
    IDL_Message(IDL_M_GENERIC, IDL_MSG_LONGJMP, "Usage: p = UDF_PIDF( key )");

  /*
  ** Our lone argument is a "key", obtained from UDF_KEY().  Although it
  ** seems unlikely that our caller will mess around with that key, still,
  ** let's be paranoid and have IDL_EzCall() check it for sanity.
  */

  IDL_EzCall(Argc, Argv, arg_struct);
  Key = arg_struct[0].uargv->value.ul;
  IDL_EzCallCleanup(Argc, Argv, arg_struct);

  rV = ReadPidf(Key, PIDF);
  if (rV != ALL_OKAY) 
     udf_barf(NULL, rV);

  return udf_pidf_c2idl((struct Pidf *)PIDF);
}
