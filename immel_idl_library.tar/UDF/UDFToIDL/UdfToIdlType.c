#include <stdio.h>
#include <stdarg.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <math.h>

#include <export.h>

#include <local_defs.h>
#include <user_defs.h>
#include <idf_defs.h>
#include <DbDefs.h>
#include <ret_codes.h>
#include <libbase_udf.h>
#include <PidfAnsi.h>
#include <PidfStr.h>
#include <PidfRets.h>
#include <libCfg.h>
#include <StrHier.h>
#include <dbf.h>

#include "udfdlm_defs.h"
#include "udfdlm_ansi.h"
#include "udfdlm_str.h"

/** NOTE THAT THIS ROUTINE WORKS ONLY ON UDF SENSOR DEFINITIONS!  TRY IT **/
/** ON ANYTHING ELSE AND YOUR GUESS IS AS GOOD AS MINE WHAT IF ANY       **/
/** RESULTS YOU WILL GET.                                                **/

/** TO AVOID UNPLEASENTRIES THE SENSOR CHECK IS NOW INTERNAL             **/

/** MADE SOME CHANGES TO THIS ROUTINE.  THERE WERE TOO MANY GAPPING      **/
/** HOLES TO FALL WITH AN ERROR MESSAGE RESULTING - CAG                  **/ 

int udf_to_idl_type (struct fh_cache *fh, ByTe_4 N)
{
  extern u_ByTe_2 Version;
  extern ByTe_1 Ext[];
  ByTe_1 dtype, dlen;
  ByTe_4 sN;
  ByTe_2 rV;
  int    GiveBack = -1;

  /*
  ** Read the sensor datatype & bit length.  From that, determine ID type
  */

  Key = fh->Key;
  struct PidfSensor *ps = (struct PidfSensor *)(fh->PIDF->Sensors);

  if (ps[N]->Src == 'V')
  {
     sN = ps[N].VidfNum;
     rV = read_idf(Key, Ext, Version, (ByTe_1*)&dtype, _DataTypE, 0, sN, 1);
     if (rV != ALL_OKAY)
       udf_barf("u2i_1", rV);

     rV = read_idf(Key, Ext, Version, (ByTe_1*)&dlen, _TdwLeN,    0, sN, 1);
     if (rV != ALL_OKAY)
       udf_barf("u2i_1", rV);

  /*
  ** See <URL:http://pluto.space.swri.edu/~frio/VIDFPg/SenInfo.html> for
  ** a description of the VIDF data types and lengths.  The latter is
  ** simple: just a bit length (8, 16, 32).  The former, data type, is
  ** more complex.
  **
  ** According to the table at that URL, <0> is unsigned int (of whatever
  ** bit length, byte/short/long), <1> is signed int (ditto), and <2> is
  ** standard 32-bit IEEE floating-point.  The rest are some  weird form 
  ** of UDF floating point representation.
  **
  ** Since IMAGE only seems to have 0, 1, and 2, I won't waste time
  ** supporting the rest.
  */
     switch (dtype) {
        case 0:
        case 1:
           GiveBack (dlen <= 8) ? IDL_TYP_BYTE :
                    (dlen <= 16) ? IDL_TYP_UINT : IDL_TYP_ULONG;
        break;
        case 1:
           GiveBack (dlen <= 8) ? IDL_TYP_BYTE :
                   (dlen <= 16) ? IDL_TYP_INT : IDL_TYP_LONG;
        break;
        case 2:	
           GiveBack = IDL_TYP_FLOAT;
        break;

    /*
    ** Anything other than 0-2 is an error.  Is it ours, though?  Sure,
    ** we don't support everything defined in the UDF spec (above).  
    **
    ** On 2000-01-20, however, Harald Frey encountered a dtype of 16.
    ** I responded with my strong hunch that the VIDF is broken, and
    ** "dtype" got confused with "dlen".  Word isn't back yet, but
    ** let's at least try to catch that error if it happens again,
    ** and provide a clue to the user.
    */
        case 3:
        case 4:
        case 5:
        case 6:
          idl_barf("Unrecognized sensor type '%d' (Ed's fault: although UDF defines 0-6, UDF-DLM only supports 0, 1, and 2).", dtype);

    /*
    ** Nope, not Ed's fault (unless the spec has changed).
    */
        default:
          idl_barf("Unrecognized sensor type '%d'.  I bet your VIDF is broken!",
		 dtype);
     }
  }

  return GiveBack;	/* for gcc */
}
