#include <stdio.h>
#include <stdarg.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <math.h>

#include <export.h>

#include "udfdlm_ansi.h"

/*
** Garbage collection: IDL calls us when it's done with a data chunk.
** We could just make IDL call free(), but we'd get compiler warnings.
*/

void UdfFree( UCHAR *ptr )
{
    if (ptr != NULL)
       free(ptr);
    ptr = NULL;
}
