#include <stdio.h>
#include <stdarg.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <math.h>

#include <export.h>

#include <local_defs.h>
#include <user_defs.h>
#include <idf_defs.h>
#include <ret_codes.h>
#include <libbase_udf.h>
#include <PidfAnsi.h>
#include <PidfStr.h>
#include <PidfRets.h>

#include "udfdlm_ansi.h"

UCHAR udfdlm_idl_fieldtype(ByTe_4 DataField, struct fh_cache *fh, ByTe_4 N)
{
   extern u_ByTe_2 Version;
   extern ByTe_1 Ext[];

   struct PidfSensor *ps = (struct PidfSensor *)(fh->PIDF->Sensors);
   struct PidfAnc    *pa = (struct PidfAnc *)(fh->PIDF->Ancil);

   u_ByTe_4 Key;
   ByTe_1 dlen;
   UCHAR  ftype;
   ByTe_2 rV;

   Key = fh->Key;
   switch (DataField)
   {
      case SENSOR:
         if (ps[N].Src == 'V')
            rV = read_idf(Key, Ext, Version, &dlen, _TdwLeN, 0, 
                          ps[N].VidfNum, 1);
         else
            rV = read_idf(Key, Ext, Version, &dlen, _CalWleN, 0, 
                          ps[N].VidfNum, 1);
         ftype = (abs(dlen) > 16 ? IDL_TYP_DOUBLE : IDL_TYP_FLOAT);
      break;
      case MODE:
         ftype = IDL_TYP_FLOAT;
      break;
      case ANCILLARY:
         rV = read_idf(Key, Ext, Version, &dlen, _CalWleN, 0, 
                          pa[N].VidfNum, 1);
         ftype = (abs(dlen) > 16 ? IDL_TYP_DOUBLE : IDL_TYP_FLOAT);
      break;
   }

   return (ftype);
}
