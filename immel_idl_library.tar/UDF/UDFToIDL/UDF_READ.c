#include <stdio.h>
#include <stdarg.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <math.h>

#include <export.h>

#include <local_defs.h>
#include <user_defs.h>
#include <idf_defs.h>
#include <DbDefs.h>
#include <ret_codes.h>
#include <libbase_udf.h>
#include <PidfAnsi.h>
#include <PidfStr.h>
#include <PidfRets.h>
#include <libCfg.h>
#include <StrHier.h>
#include <dbf.h>

#include "udfdlm_defs.h"
#include "udfdlm_ansi.h"

/**************\
|*  UDF_READ  *|  Reads one complete record from the UDF dataset
\**************/

FUNCTION UDF_READ(int Argc, IDL_VPTR Argv[], char *kw_unused)
{
   extern struct fh_cache fh_list[];
   extern u_ByTe_2 Version;
   extern ByTe_1 Ext[];
   extern void *UDF;

   struct idf_data    *U;
   struct Pidf        *P;
   struct PidfSensor  *Px;
   struct PidfUnit    *Pu;

   ByTe_4 NSmp;
   float  *TmpF;
   ByTe_2 *s1;
   ByTe_2 SeN, M, N;
   ByTe_2 rV;
   ByTe_2 EndN, EndM;
   ByTe_1 TimeFilled = 0;
   ByTe_1 Fwd;

   IDL_LONG         one = 1;

   struct basic_struct {
     struct udf_time btime;
     struct udf_time etime;
     IDL_LONG  dlen;
     char   data[8];
   };

   struct basic_struct *arr;
   ByTe_1 *base, *trac;

   struct fh_cache *fh;

   ByTe_4 FhNum;

   if (Argc == 1) {
      FhNum = Argv[0]->value.i;
      fh = &fh_list[FhNum];
   } else
      IDL_Message(IDL_M_GENERIC, IDL_MSG_LONGJMP, 
                                "Usage: dS = UDF_READ(fh)");

   /********************************************************/
   /* Allocate space for the structure if no space present */
   /********************************************************/

   U = (struct idf_data *)UDF;
   if (fh->dA == NULL) {
      if ((fh->dA = malloc(fh->dSize)) == NULL)
        idl_barf("UDF_READ: malloc(fh->dA) failed!");
   }
   arr = (struct basic_struct *)fh->dA;
   base = (ByTe_1 *) &(arr->data);

   P = (struct Pidf *)fh->PIDF;
   Px = (struct PidfSensor *)P->Sensors;
   Pu = (struct PidfUnit *)P->Units;
   
  /**************************************************************************/
  /*                                                                        */
  /*                   HERE STARTS THE GREAT DATA GRAB                      */
  /*                                                                        */
  /*  Look over the ordered sensors picking them up in the order determined */
  /*  Only pick up the VIDF sensors and not the ancillary data.             */
  /*                                                                        */
  /*  Outer loop is the matrix column loop.  Needs to be outer in case      */
  /*  there are multiple sensors and the matrix extends beyond a single     */
  /*  data record.                                                          */
  /*                                                                        */
  /**************************************************************************/

  EndN = fh->TotVSen - 1;
  EndM = fh->NCols - 1;
  for (M = 0; M < fh->NCols; M++) {
     s1 = (ByTe_2 *)fh->Order;
     for (N = 0; N < fh->TotVSen; N++, ++s1) {
        SeN = Px[*s1].VidfNum; 
        Fwd = (M == EndM && N == EndN) ? 1 : 0; 
        rV = read_drec(fh->Key, Ext, Version, UDF, SeN, M, Fwd, 0);
        if (rV != ALL_OKAY  &&  rV != NEXT_FILE_STATUS)
           udf_barf("ReadDrec", rV);

        if (N == 0 && M == 0)
           ConvMode (fh, base);

        if (!U->filled_data) {
           trac = base + fh->Begs[0] + SetTrac(fh, N, M, 0, 0);
           TmpF = (float *)trac;
           *TmpF = -1.0;
           continue;
        }

        NSmp = U->num_sample;
        if (!TimeFilled) {
	   udfdlm_time_fill( &arr->btime, U->byear, U->bday, U->bmilli);
           TimeFilled = 1;
           arr->dlen = U->num_sample;
        }
	udfdlm_time_fill( &arr->etime, U->eyear, U->eday, U->emilli);

        trac = base + fh->Begs[0] + SetTrac(fh, N, M, 0, 0);
        TmpF = (float *)trac;
        *TmpF = (float)U->d_qual;

        ConvPhase (fh, base, N, M);
        ConvTheta (fh, base, N, M);
        ConvIndex (fh, base, N, M);
        ConvSensor (fh, base, N, M);
        ConvAnc (fh, base, N, M);
     }
  }

  /*
  ** Move the data we just read in into an IDL structure
  */

  return IDL_ImportArray(1, &one, IDL_TYP_STRUCT, (UCHAR*)arr, NULL, fh->sdef);
}
