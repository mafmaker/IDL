#include <stdio.h>
#include <stdarg.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <math.h>

#include <export.h>

#include <local_defs.h>
#include <user_defs.h>
#include <idf_defs.h>
#include <DbDefs.h>
#include <ret_codes.h>
#include <libbase_udf.h>
#include <PidfAnsi.h>
#include <PidfStr.h>
#include <PidfRets.h>
#include <libCfg.h>
#include <StrHier.h>
#include <dbf.h>

#include "udfdlm_defs.h"
#include "udfdlm_ansi.h"

void *udfdlm_MkDataStruc( struct fh_cache *fh)
{
   extern void     *UDF;
   extern IDL_LONG *TmpDim;
   extern int      ALIGN_MASK;
   extern u_ByTe_2 Version;
   extern ByTe_1   Ext[];
   extern ByTe_1   *TmpName;
   extern void     *TmpSpace;
   extern ByTe_4   TmpBytes;

   struct idf_data     *udf;
   struct Pidf         *P;
   struct PidfSensor   *Px;
   struct PidfMode     *Pm;
   struct PidfAnc      *Pa;

   ByTe_2              *s1;
   int                 nTag = 0;
   IDL_STRUCT_TAG_DEF  *TaGs;
   void                *retval;

   ByTe_4              L = 0, N;
   ByTe_4              TotItems, Len;
   ByTe_4              D1, D2, D3;
   ByTe_4              B;
   u_ByTe_2 rV;

   ByTe_1              struct_name[1024];
   ByTe_1              How, Tname[1024];

  /******************************************************************/
  /* Get the PIDF info for this key and establish some initial      */
  /* information from the PIDF                                      */
  /******************************************************************/

   ReadPidf (fh->Key, fh->PIDF);
   P = (struct Pidf *)fh->PIDF;
   Px = (struct PidfSensor *)P->Sensors;
   Pm = (struct PidfMode *)P->Modes;
   Pa = (struct PidfAnc *)P->Ancil;
   fh->TotMode = P->Ps.NModes;

  /******************************************************************/
  /* This is how to accumulate and output the sensor data           */      
  /******************************************************************/

   How = (fh->flags.senconfig == 1) ? 'C' : 
         (fh->flags.senconfig == 2) ? 'G' : 'S'; 
   fh->sType = (fh->flags.dformat == 0) ? IDL_TYP_FLOAT : IDL_TYP_DOUBLE;

  /******************************************************************/
  /* Establish enough space to set up the necessary information to  */
  /* identify what's to be returned.  We can set the aLoc and aDim  */
  /* pointers at this time since they are fixed.                    */
  /******************************************************************/


   TotItems = P->Ps.NSensors + P->Ps.NAncils;     /* Total Sensors  */
   Len = 3 * TotItems + P->Ps.NModes;
   B = (Len + TotItems) * sizeof(ByTe_2);

   if ((fh->sOrder = (ByTe_2 *)malloc(B)) == NULL)
        idl_barf("make_idl_struct: malloc(sOrder)");
   fh->aLoc = (ByTe_1 *)(fh->sOrder + Len);
   fh->aDim = fh->aLoc + TotItems;

  /********************************************************************/
  /* Count and tag the VIDF sensors in the PIDF Sensor Definitions    */
  /* Once we know this we can set pointers to other fh Arrays.        */
  /********************************************************************/

   UdfCntItems (SENSOR, fh);

   fh->aOrder = fh->sOrder + fh->TotVSen;
   fh->sUnits = fh->aOrder + fh->TotAnc;
   fh->aUnits = fh->sUnits + fh->TotVSen;
   fh->mUnits = fh->aUnits + fh->TotAnc;
   fh->aSet   = (ByTe_1 *)(fh->mUnits + fh->TotMode);

  /********************************************************************/
  /* Now Do the ancillary data sets and all necessary array loads     */
  /********************************************************************/

   UdfCntItems (ANCILLARY, fh);

   TotItems = fh->TotMode + fh->TotVSen + fh->TotAnc;

   /*****************************************************************/
   /* Do all our pre mallocs here                                   */
   /*****************************************************************/

   B = (TotItems + MAX_TAGS) * sizeof(IDL_STRUCT_TAG_DEF);
   if ((TaGs = (IDL_STRUCT_TAG_DEF *)malloc(B)) == NULL)
        idl_barf("make_idl_struct: malloc(TaGs)");

   B = (TotItems + MAX_TAGS) * MAX_TAG_LEN;
   if ((TmpName = (ByTe_1 *)malloc(B)) == NULL)
        idl_barf("make_idl_struct: malloc(TmpName)");

   B = (TotItems + MAX_TAGS) * (4 * sizeof(long));
   if ((TmpDim = (IDL_LONG *)malloc(B)) == NULL)
        idl_barf("make_idl_struct: malloc(TmpDim)");

   B = (fh->TotAnc + MAX_BEGS) * sizeof(ByTe_4);
   if ((fh->Begs = (ByTe_4 *)malloc(B)) == NULL)
        idl_barf("make_idl_struct: malloc(fh->Begs)");

   B = (fh->sType == IDL_TYP_FLOAT) ? fh->maxlen * sizeof(ReaL_4) :
                                      fh->maxlen * sizeof(ReaL_8);
   if (B > TmpBytes) {
      TmpBytes = B;
      if ((TmpSpace = realloc(TmpSpace, B)) == NULL)
         idl_barf("make_idl_struct: realloc(TmpSpace)");
   }

  /*********BUG ALERT*******BUG ALERT*******BUG ALERT******BUG ALERT*******/
  /*                                                                      */
  /*  At this point the number of Columns in the data matrix is obtained. */
  /*  A value of 1 means not matrix data.  This value as far as I can see */
  /*  is obtained once!  Matrix sizes can change within a UDF file!       */
  /*  This does not seem to be taken into account!                        */
  /*                                                                      */
  /*********BUG ALERT*******BUG ALERT*******BUG ALERT******BUG ALERT*******/

   udf = (struct idf_data *)UDF;
   rV = read_drec(fh->Key, Ext, Version, UDF, -1, 0, 0, 0);
   if (rV != ALL_OKAY)
      udf_barf("read_drec", rV);

   fh->NCols = udf->TotCols;

  /**********************************************************************/
  /*  OK - NOW FOR THE STRUCTURE!                                       */
  /*                                                                    */
  /*  Always a start and a stop time                                    */
  /**********************************************************************/

   fh->dSize = SetUpTag  (TaGs, "BTIME", UDF_TIME, 0, 0, 0, nTag++);
   fh->dSize += SetUpTag (TaGs, "ETIME", UDF_TIME, 0, 0, 0, nTag++);

  /**********************************************************************/
  /*  Always some data quality flags - but how many?                    */
  /*                                                                    */
  /*  One per sensor at least but if this is a matrix sensor then there */
  /*  is one per matrix column                                          */
  /**********************************************************************/

   SetDims (fh, &D1, &D2, &D3, 6);
   fh->Begs[L++] = 0;
   fh->dSize += SetUpTag (TaGs, "D_QUAL", IDL_TYP_FLOAT, D1, D2, D3, 
                              nTag++);

  /**********************************************************************/
  /*  Always some azimuth data, start and stop.  How many here depends  */
  /*  on how and if the keyword was set.  You get choices of 0) just    */
  /*  give it for the first sensor or 1) give it for all sensors.  In   */
  /*  the latter case you get it for all matrix elements if the data    */
  /*  is stored in matrix format.                                       */ 
  /**********************************************************************/

   PAD(fh->dSize, 4);
   fh->Begs[L++] = fh->dSize;
   SetDims (fh, &D1, &D2, &D3, 0);
   fh->dSize += SetUpTag (TaGs, "START_AZ", IDL_TYP_FLOAT, D1, D2, 
                             D3, nTag++);
   fh->Begs[L++] = fh->dSize;
   fh->dSize += SetUpTag (TaGs, "STOP_AZ", IDL_TYP_FLOAT,  D1, D2, 
                             D3, nTag++);

  /**********************************************************************/
  /*  Always some theta data, start and stop.  How many here depends    */
  /*  on how and if the keyword was set.  You get choices of 0) just    */
  /*  give it once per sensor or if matrix once per sensor per matrix   */
  /*  column;  1) give it for each element in the sensors and for       */
  /*  matrix data once for each matrix element.                         */
  /**********************************************************************/

   fh->Begs[L++] = fh->dSize;
   SetDims (fh, &D1, &D2, &D3, 1);
   fh->dSize += SetUpTag (TaGs, "START_TH", IDL_TYP_FLOAT, D1, D2, 
                             D3, nTag++);
   fh->Begs[L++] = fh->dSize;
   fh->dSize += SetUpTag (TaGs, "STOP_TH", IDL_TYP_FLOAT,  D1, D2, 
                             D3, nTag++);

  /**********************************************************************/
  /*  Throw in the array indices if this is an array or matrix UDF.     */
  /*  Same storage scheme as the azimuth data                           */
  /**********************************************************************/

   if (fh->sample_id != 2) {
      udfdlm_fill_units(SCAN_INDEX, fh);       /* Fill In Unit Numbers */
      fh->Begs[L++] = fh->dSize;
      SetDims (fh, &D1, &D2, &D3, 2);
      fh->dSize += SetUpTag (TaGs, "AINDICES", IDL_TYP_FLOAT, D1, 
                                D2, D3, nTag++);
   } else
      fh->Begs[L++] = -1;
 
  /**********************************************************************/
  /*  OK - now determine how we are going to save the science data.     */
  /**********************************************************************/

   if (fh->sType == IDL_TYP_DOUBLE)
       PAD(fh->dSize, 8);
   fh->Begs[L++] = fh->dSize;

  /**********************************************************************/
  /*  OK - create the data structures                                   */
  /**********************************************************************/

   switch (How)
   {
      case 'S':

        udfdlm_fill_units(SENSOR, fh);         /* Fill In Unit Numbers */
        SetDims (fh, &D1, &D2, &D3, 5);        /* select dimensions    */
        s1 = (ByTe_2 *)fh->sOrder;
        for (N=0; N < fh->TotVSen; N++) {
           udfdlm_make_idl_tag_name(Px[*s1++].Name, Tname);
           fh->dSize += SetUpTag(TaGs, Tname, fh->sType, D1, D2, D3, nTag++);
        }
      break;
   }

  /**********************************************************************/
  /*  Next do modes if there are any around                             */
  /**********************************************************************/

   if (fh->TotMode > 0) {
      fh->Begs[L++] = fh->dSize;
      udfdlm_fill_units(MODE, fh);               /* Fill In Unit Numbers */
      SetDims (fh, &D1, &D2, &D3, 7);
      for (N = 0; N < fh->TotMode; N++) {
         udfdlm_make_idl_tag_name(Pm[N].LDesc, Tname);
         fh->dSize += SetUpTag(TaGs, Tname, IDL_TYP_FLOAT, D1, D2, 
                               D3, nTag++);
      } 
   } else
      fh->Begs[L++] = -1;
 
   
  /**********************************************************************/
  /*  And last try some ancillary data sets                             */
  /**********************************************************************/

   L = MAX_BEGS;
   if (fh->TotAnc > 0) {
      udfdlm_fill_units(ANCILLARY, fh);            /* Fill In Unit Numbers */
      for (N = 0; N < fh->TotAnc; N++) {
         fh->Begs[L++] = fh->dSize;
         D1 = N;
         SetDims (fh, &D1, &D2, &D3, 8);
         if (fh->aLoc[N] == 'S') 
            udfdlm_make_idl_tag_name(Px[fh->aOrder[N]].Name, Tname);
         else
            udfdlm_make_idl_tag_name(Pa[fh->aOrder[N]].LDesc, Tname);
         fh->dSize += SetUpTag (TaGs, Tname, fh->sType, D1, D2, D3, nTag++);
      } 
   } else
      fh->Begs[L++] = -1;

   sprintf (struct_name, "%s_%c", fh->BaseName, How);

   /***********************************************************************/
   /*  Not sure why we need this extra pad but without it you can not do  */
   /*  multiple UDF_READS.  So for now it stays                           */
   /***********************************************************************/

   fh->dSize += 100;

   TaGs[nTag].name = 0;
   retval = IDL_MakeStruct(struct_name, TaGs);

   free(TaGs);
   free(TmpName);
   free(TmpDim);

   return retval;
}
