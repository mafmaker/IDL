#include <stdio.h>
#include <stdarg.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <math.h>

#include <export.h>

#include "udfdlm_ansi.h"

/*
** Useful emit-error-and-exit routine
*/

void idl_barf( char *fmt, ... )
{
  va_list args;
  char    buf[1024];

  va_start(args, fmt);
  vsprintf(buf, fmt, args);

  IDL_Message(IDL_M_NAMED_GENERIC, IDL_MSG_LONGJMP, buf);
}
