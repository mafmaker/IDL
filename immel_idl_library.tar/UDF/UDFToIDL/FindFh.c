#include <stdio.h>
#include <stdarg.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <math.h>

#include <export.h>

#include "udfdlm_defs.h"
#include "udfdlm_ansi.h"

ByTe_4 FindFh (u_ByTe_4 Key)
{
   extern struct fh_cache fh_list[];
   
   struct fh_cache *fh;
   ByTe_4 free_fh;

  /************************************************************************/
  /*  Given a UDF Key match it up with a file handle structure.  If one   */
  /*  doesn't exist then assign one to the key.                           */
  /************************************************************************/

  for (free_fh = 0; free_fh < MAX_OPEN; ++free_fh)
      if (fh_list[free_fh].Key == Key)
         break;

  /* We haven't seen this key before... now look for an empty slot */

   if (free_fh == MAX_OPEN) {
      for (free_fh = 0; free_fh < MAX_OPEN; free_fh++)
         if (fh_list[free_fh].Key == 0)
            break;

      if (free_fh == MAX_OPEN)
         idl_barf("too many open UDFs; limit is %d\n", MAX_OPEN);

       fh = &fh_list[free_fh];
       fh->Key = Key;
       fh->PIDF = NULL;
       fh->Units = NULL;
       fh->Order = NULL;
       fh->pInfo = NULL;
       fh->dA = NULL;
       fh->Begs = NULL;
       fh->is_open = 0;
       fh->tV = 0;
       fh->flags.baseunit = 1;
   }

   return (free_fh);
}
