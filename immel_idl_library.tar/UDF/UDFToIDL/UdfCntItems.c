#include <stdio.h>
#include <stdarg.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <math.h>

#include <export.h>

#include <user_defs.h>
#include <PidfStr.h>
#include <PidfAnsi.h>

#include "udfdlm_ansi.h"
#include "udfdlm_str.h"

void UdfCntItems (ByTe_2 Item, struct fh_cache *fh)
{
   struct Pidf *P;
   struct PidfSensor *Px;
   struct PidfAnc *Pa;

   register ByTe_2 *s1, *s2;
   register ByTe_1 *c1, *c2;

   ByTe_4 M, N, aV;
   ByTe_4 NSAnc = 0;

   P = (struct Pidf *)fh->PIDF;
   Px = (struct PidfSensor *)P->Sensors;
   Pa = (struct PidfAnc *)P->Ancil;

   switch (Item) {
      case SENSOR:
         s1 = fh->sOrder;
         fh->TotVSen = 0;
         for (N=0; N < P->Ps.NSensors; N++) {
            if (Px[N].Src == 'V') {
                fh->TotVSen += 1;
                *s1++ = N;
            }
         }
         fh->TotAnc = P->Ps.NSensors + P->Ps.NAncils - fh->TotVSen;
      break;

      case ANCILLARY:
         s1 = fh->aOrder;
         c1 = fh->aLoc;
         c2 = fh->aSet;

         for (N=0; N <P->Ps.NSensors; N++) {
            if (Px[N].Src == 'A') {
               *s1++ = Px[N].PidfNum;
               *c1++ = 'S';
               *c2++ = Px[N].VidfNum;
               ++NSAnc;
            }
         }

         for (N=0; N <P->Ps.NAncils; N++) {
            aV = Pa[N].VidfNum;
            s2 = fh->aOrder;
            for (M = 0; M < NSAnc; ++M) {
               if (aV == Px[*s2++].VidfNum)
                  break;
            }

            if (M == NSAnc) {
               *s1++ = Pa[N].PidfNum;
               *c1++ = 'A';
               *c2++ = Pa[N].VidfNum;
            }
         }
      break;
   }
}
