#include <stdio.h>
#include <stdarg.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <math.h>

#include <export.h>

#include <local_defs.h>
#include <user_defs.h>
#include <idf_defs.h>
#include <DbDefs.h>
#include <ret_codes.h>
#include <libbase_udf.h>
#include <PidfAnsi.h>
#include <PidfStr.h>
#include <PidfRets.h>
#include <libCfg.h>
#include <StrHier.h>
#include <dbf.h>

#include "udfdlm_defs.h"
#include "udfdlm_ansi.h"

int udf_num_bytes( int type )
{
  switch (type) {
    case IDL_TYP_BYTE:	return 1;

    case IDL_TYP_INT:
    case IDL_TYP_UINT:	return 2;

    case IDL_TYP_LONG:
    case IDL_TYP_ULONG:
    case IDL_TYP_FLOAT: return 4;

    case IDL_TYP_DOUBLE: return 8;
  }

  IDL_Message(IDL_M_NAMED_GENERIC, IDL_MSG_RET, "unknown type");

  return 4;
}
