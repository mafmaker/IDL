#include <stdio.h>
#include <stdarg.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <math.h>

#include <export.h>

#include "udfdlm_defs.h"
#include "udfdlm_ansi.h"

ByTe_4 SetUpTag(IDL_STRUCT_TAG_DEF *Tag, ByTe_1 *TagName, ByTe_4 Type, 
                ByTe_4 *Dim, ByTe_4 nTag)
{
    extern void *s_udf_time;
    extern void *TmpName;
    extern IDL_LONG *TmpDim;

    IDL_LONG *l1;
    ByTe_4 Tot, D1, D2, D3;
    ByTe_1 *c1;

    c1 = TmpName + MAX_TAG_LEN * nTag;
    l1 = TmpDim + 4 * nTag;
    D1 = Dim[0];
    D2 = Dim[1];
    D3 = Dim[2];

    strcpy (c1, TagName);

    Tag[nTag].name = c1;
    Tag[nTag].flags = 0;

    switch (Type)
    {
       case UDF_TIME: 
         Tag[nTag].type = s_udf_time;
         Tot = 0;
       break;
       case IDL_TYP_BYTE: 
         Tag[nTag].type = (void *)IDL_TYP_BYTE;
         Tot = sizeof (char);
       break;
       case IDL_TYP_LONG: 
         Tag[nTag].type = (void *)IDL_TYP_LONG;
         Tot = sizeof (long);
       break;
       case IDL_TYP_FLOAT: 
         Tag[nTag].type = (void *)IDL_TYP_FLOAT;
         Tot = sizeof (float);
       break;
       case IDL_TYP_DOUBLE: 
         Tag[nTag].type = (void *)IDL_TYP_DOUBLE;
         Tot = sizeof (double);
       break;
    }

    l1[0] = (D1 <= 0) ? 0 : (D2 == 0) ? 1 : (D3 == 0) ? 2 : 3;
    l1[1] = D1;
    l1[2] = D2;
    l1[3] = D3;
    Tag[nTag].dims = l1;

    if (D1 == 0) D1 = 1;
    if (D2 == 0) D2 = 1;
    if (D3 == 0) D3 = 1;

    Tot *= D1 * D2 * D3;

    return (Tot);
}
