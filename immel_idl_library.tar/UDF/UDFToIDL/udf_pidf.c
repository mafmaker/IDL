static char const Ident[] =
  "@(#) $Id: udf_pidf.c: built 2000-04-20 by gen_udf_pidf.pl v1.2 $";
/*
** udf_pidf.c
**
** Given a PIDF structure, convert it to IDL form
*/
#include <PidfStr.h>
#include <stdlib.h>
#include <export.h>		/* IDL definitions */

#include "udfdlm_defs.h"
#include "udfdlm_ansi.h"

struct s_values_sensor {
  IDL_STRING Name;
  IDL_STRING Comp;
  IDL_STRING Src;
  IDL_STRING ScfFile;
  IDL_STRING PitchAng;
  ByTe_1     Display;
  ByTe_2     PidfNum;
  ByTe_2     VidfNum;
  ByTe_2     AncSen;
  ByTe_2     GroupNum;
  ByTe_2     ScanBlk;
  ByTe_2     BinBlk;
  ByTe_2     NUnits;
  ByTe_2     Units[1024];
};
static void *s_sensor;

struct s_values_unit {
  ByTe_4     Id;
  ByTe_4     LocalId;
  ReaL_4     Min;
  ReaL_4     Max;
  IDL_STRING ULab;
  IDL_STRING LDesc;
  IDL_STRING SDesc;
  ByTe_2     Sca;
  ByTe_2     NTbls;
  ByTe_1     Tbls[1024];
  ByTe_2     Ops[1024];
};
static void *s_unit;

struct s_values_scan {
  ByTe_2     NUnits;
  ByTe_2     Units[1024];
  ByTe_2     VUnits[1024];
  IDL_STRING Loc;
  IDL_STRING Step;
};
static void *s_scan;

struct s_values_mode {
  IDL_STRING LDesc;
  IDL_STRING SDesc;
  ByTe_2     PidfNum;
  ByTe_2     VidfNum;
  ByTe_2     NUnits;
  ByTe_2     Units[1024];
};
static void *s_mode;

struct s_values_ancil {
  IDL_STRING LDesc;
  IDL_STRING SDesc;
  ByTe_2     PidfNum;
  ByTe_2     VidfNum;
  ByTe_2     NUnits;
  ByTe_2     Units[1024];
  ByTe_2     NSen;
  ByTe_2     Sen[1024];
  ByTe_1     Modify;
};
static void *s_ancil;


/*
** Convert a UDF PidfSensor struct to an IDL struct
*/
static void c2idl_PidfSensor( struct PidfSensor *p, long n, struct s_values_sensor arr[] )
{
  int       i,j;
  char      charbuf[2];	/* for chars that are strings */
  static IDL_LONG  dims_units[] = { 1, 1024 };

  IDL_STRUCT_TAG_DEF s_tags_sensor[] = {
  { "NAME",     0, (void*)IDL_TYP_STRING },   /* ByTe_1 * Name     */
  { "COMP",     0, (void*)IDL_TYP_STRING },   /* ByTe_1 * Comp     */
  { "SRC",      0, (void*)IDL_TYP_STRING },   /* ByTe_1   Src      */
  { "SCFFILE",  0, (void*)IDL_TYP_STRING },   /* ByTe_1 * ScfFile  */
  { "PITCHANG", 0, (void*)IDL_TYP_STRING },   /* ByTe_1   PitchAng */
  { "DISPLAY",  0, (void*)IDL_TYP_BYTE   },   /* ByTe_1   Display  */
  { "PIDFNUM",  0, (void*)IDL_TYP_INT    },   /* ByTe_2   PidfNum  */
  { "VIDFNUM",  0, (void*)IDL_TYP_INT    },   /* ByTe_2   VidfNum  */
  { "ANCSEN",   0, (void*)IDL_TYP_INT    },   /* ByTe_2   AncSen   */
  { "GROUPNUM", 0, (void*)IDL_TYP_INT    },   /* ByTe_2   GroupNum */
  { "SCANBLK",  0, (void*)IDL_TYP_INT    },   /* ByTe_2   ScanBlk  */
  { "BINBLK",   0, (void*)IDL_TYP_INT    },   /* ByTe_2   BinBlk   */
  { "NUNITS",   0, (void*)IDL_TYP_INT    },   /* ByTe_2   NUnits   */
  { "UNITS",    dims_units, (void*)IDL_TYP_INT    },   /* ByTe_2 * Units    */
    { 0 }
  };

  s_sensor = IDL_MakeStruct("PIDF_SENSOR", s_tags_sensor);

  for (i=0; i<n; i++) {
    IDL_StrStore(&arr[i].Name,      p[i].Name);
    IDL_StrStore(&arr[i].Comp,      p[i].Comp);
    charbuf[0] = p[i].Src; charbuf[1] = '\0';
    IDL_StrStore(&arr[i].Src,       charbuf);
    IDL_StrStore(&arr[i].ScfFile,   p[i].ScfFile);
    charbuf[0] = p[i].PitchAng; charbuf[1] = '\0';
    IDL_StrStore(&arr[i].PitchAng,  charbuf);
                  arr[i].Display  = p[i].Display;
                  arr[i].PidfNum  = p[i].PidfNum;
                  arr[i].VidfNum  = p[i].VidfNum;
                  arr[i].AncSen   = p[i].AncSen;
                  arr[i].GroupNum = p[i].GroupNum;
                  arr[i].ScanBlk  = p[i].ScanBlk;
                  arr[i].BinBlk   = p[i].BinBlk;
                  arr[i].NUnits   = p[i].NUnits;
    for (j=0; j<p[i].NUnits; j++)
      arr[i].Units[j] = p[i].Units[j];
  }
}

/*
** Convert a UDF PidfUnit struct to an IDL struct
*/
static void c2idl_PidfUnit( struct PidfUnit *p, long n, struct s_values_unit arr[] )
{
  int       i,j;
  static IDL_LONG  dims_tbls[] = { 1, 1024 };
  static IDL_LONG  dims_ops[] = { 1, 1024 };

  IDL_STRUCT_TAG_DEF s_tags_unit[] = {
  { "ID",      0, (void*)IDL_TYP_LONG   },   /* ByTe_4   Id      */
  { "LOCALID", 0, (void*)IDL_TYP_LONG   },   /* ByTe_4   LocalId */
  { "MIN",     0, (void*)IDL_TYP_FLOAT  },   /* ReaL_4   Min     */
  { "MAX",     0, (void*)IDL_TYP_FLOAT  },   /* ReaL_4   Max     */
  { "ULAB",    0, (void*)IDL_TYP_STRING },   /* ByTe_1 * ULab    */
  { "LDESC",   0, (void*)IDL_TYP_STRING },   /* ByTe_1 * LDesc   */
  { "SDESC",   0, (void*)IDL_TYP_STRING },   /* ByTe_1 * SDesc   */
  { "SCA",     0, (void*)IDL_TYP_INT    },   /* ByTe_2   Sca     */
  { "NTBLS",   0, (void*)IDL_TYP_INT    },   /* ByTe_2   NTbls   */
  { "TBLS",    dims_tbls, (void*)IDL_TYP_BYTE   },   /* ByTe_1 * Tbls    */
  { "OPS",     dims_ops, (void*)IDL_TYP_INT    },   /* ByTe_2 * Ops     */
    { 0 }
  };

  s_unit = IDL_MakeStruct("PIDF_UNIT", s_tags_unit);

  for (i=0; i<n; i++) {
                  arr[i].Id      = p[i].Id;
                  arr[i].LocalId = p[i].LocalId;
                  arr[i].Min     = p[i].Min;
                  arr[i].Max     = p[i].Max;
    IDL_StrStore(&arr[i].ULab,     p[i].ULab);
    IDL_StrStore(&arr[i].LDesc,    p[i].LDesc);
    IDL_StrStore(&arr[i].SDesc,    p[i].SDesc);
                  arr[i].Sca     = p[i].Sca;
                  arr[i].NTbls   = p[i].NTbls;
    for (j=0; j<p[i].NTbls; j++)
      arr[i].Tbls[j] = p[i].Tbls[j];
    for (j=0; j<p[i].NTbls; j++)
      arr[i].Ops[j] = p[i].Ops[j];
  }
}

/*
** Convert a UDF PidfScan struct to an IDL struct
*/
static void c2idl_PidfScan( struct PidfScan *p, long n, struct s_values_scan arr[] )
{
  int       i,j;
  static IDL_LONG  dims_units[] = { 1, 1024 };
  static IDL_LONG  dims_vunits[] = { 1, 1024 };

  IDL_STRUCT_TAG_DEF s_tags_scan[] = {
  { "NUNITS", 0, (void*)IDL_TYP_INT    },   /* ByTe_2   NUnits */
  { "UNITS",  dims_units, (void*)IDL_TYP_INT    },   /* ByTe_2 * Units  */
  { "VUNITS", dims_vunits, (void*)IDL_TYP_INT    },   /* ByTe_2 * VUnits */
  { "LOC",    0, (void*)IDL_TYP_STRING },   /* ByTe_1 * Loc    */
  { "STEP",   0, (void*)IDL_TYP_STRING },   /* ByTe_1 * Step   */
    { 0 }
  };

  s_scan = IDL_MakeStruct("PIDF_SCAN", s_tags_scan);

  for (i=0; i<n; i++) {
                  arr[i].NUnits = p[i].NUnits;
    for (j=0; j<p[i].NUnits; j++)
      arr[i].Units[j] = p[i].Units[j];
    for (j=0; j<p[i].NUnits; j++)
      arr[i].VUnits[j] = p[i].VUnits[j];
    IDL_StrStore(&arr[i].Loc,     p[i].Loc);
    IDL_StrStore(&arr[i].Step,    p[i].Step);
  }
}

/*
** Convert a UDF PidfMode struct to an IDL struct
*/
static void c2idl_PidfMode( struct PidfMode *p, long n, struct s_values_mode arr[] )
{
  int       i,j;
  static IDL_LONG  dims_units[] = { 1, 1024 };

  IDL_STRUCT_TAG_DEF s_tags_mode[] = {
  { "LDESC",   0, (void*)IDL_TYP_STRING },   /* ByTe_1 * LDesc   */
  { "SDESC",   0, (void*)IDL_TYP_STRING },   /* ByTe_1 * SDesc   */
  { "PIDFNUM", 0, (void*)IDL_TYP_INT    },   /* ByTe_2   PidfNum */
  { "VIDFNUM", 0, (void*)IDL_TYP_INT    },   /* ByTe_2   VidfNum */
  { "NUNITS",  0, (void*)IDL_TYP_INT    },   /* ByTe_2   NUnits  */
  { "UNITS",   dims_units, (void*)IDL_TYP_INT    },   /* ByTe_2 * Units   */
    { 0 }
  };

  s_mode = IDL_MakeStruct("PIDF_MODE", s_tags_mode);

  for (i=0; i<n; i++) {
    IDL_StrStore(&arr[i].LDesc,    p[i].LDesc);
    IDL_StrStore(&arr[i].SDesc,    p[i].SDesc);
                  arr[i].PidfNum = p[i].PidfNum;
                  arr[i].VidfNum = p[i].VidfNum;
                  arr[i].NUnits  = p[i].NUnits;
    for (j=0; j<p[i].NUnits; j++)
      arr[i].Units[j] = p[i].Units[j];
  }
}

/*
** Convert a UDF PidfAnc struct to an IDL struct
*/
static void c2idl_PidfAnc( struct PidfAnc *p, long n, struct s_values_ancil arr[] )
{
  int       i,j;
  static IDL_LONG  dims_units[] = { 1, 1024 };
  static IDL_LONG  dims_sen[] = { 1, 1024 };

  IDL_STRUCT_TAG_DEF s_tags_ancil[] = {
  { "LDESC",   0, (void*)IDL_TYP_STRING },   /* ByTe_1 * LDesc   */
  { "SDESC",   0, (void*)IDL_TYP_STRING },   /* ByTe_1 * SDesc   */
  { "PIDFNUM", 0, (void*)IDL_TYP_INT    },   /* ByTe_2   PidfNum */
  { "VIDFNUM", 0, (void*)IDL_TYP_INT    },   /* ByTe_2   VidfNum */
  { "NUNITS",  0, (void*)IDL_TYP_INT    },   /* ByTe_2   NUnits  */
  { "UNITS",   dims_units, (void*)IDL_TYP_INT    },   /* ByTe_2 * Units   */
  { "NSEN",    0, (void*)IDL_TYP_INT    },   /* ByTe_2   NSen    */
  { "SEN",     dims_sen, (void*)IDL_TYP_INT    },   /* ByTe_2 * Sen     */
  { "MODIFY",  0, (void*)IDL_TYP_BYTE   },   /* ByTe_1   Modify  */
    { 0 }
  };

  s_ancil = IDL_MakeStruct("PIDF_ANCIL", s_tags_ancil);

  for (i=0; i<n; i++) {
    IDL_StrStore(&arr[i].LDesc,    p[i].LDesc);
    IDL_StrStore(&arr[i].SDesc,    p[i].SDesc);
                  arr[i].PidfNum = p[i].PidfNum;
                  arr[i].VidfNum = p[i].VidfNum;
                  arr[i].NUnits  = p[i].NUnits;
    for (j=0; j<p[i].NUnits; j++)
      arr[i].Units[j] = p[i].Units[j];
                  arr[i].NSen    = p[i].NSen;
    for (j=0; j<p[i].NSen; j++)
      arr[i].Sen[j] = p[i].Sen[j];
                  arr[i].Modify  = p[i].Modify;
  }
}

IDL_VPTR udf_pidf_c2idl( struct Pidf *PIDF )
{
  IDL_LONG one = 1;
  int      ntags = 1;
  static IDL_LONG dims_sensor[] = { 1, -99 };
  static IDL_LONG dims_unit[] = { 1, -99 };
  static IDL_LONG dims_scan[] = { 1, -99 };
  static IDL_LONG dims_mode[] = { 1, -99 };
  static IDL_LONG dims_ancil[] = { 1, -99 };

  IDL_STRUCT_TAG_DEF s_tags[7] = {
    { "KEY",   0, (void*)IDL_TYP_LONG },
    { 0 }
  };
  void *s;

  struct ddd {
    int key;
  };
  char *arr;

  arr = (char *)malloc(sizeof(struct ddd) +
                             sizeof(struct s_values_sensor) * PIDF->Ps.NSensors +
                             sizeof(struct s_values_unit) * PIDF->Ps.NUnits +
                             sizeof(struct s_values_scan) * PIDF->Ps.NScans +
                             sizeof(struct s_values_mode) * PIDF->Ps.NModes +
                             sizeof(struct s_values_ancil) * PIDF->Ps.NAncils);
  if (arr == NULL)
    idl_barf("malloc() failed");

  if (PIDF->Ps.NSensors > 0) {
    c2idl_PidfSensor((struct PidfSensor *)PIDF->Sensors,
                     PIDF->Ps.NSensors,
                     (struct s_values_sensor*)(arr + sizeof(struct ddd)));
    dims_sensor[1] = PIDF->Ps.NSensors;
    s_tags[ntags].name = "PIDF_SENSOR";
    s_tags[ntags].dims = dims_sensor;
    s_tags[ntags].type = s_sensor;
    ++ntags;
  }
  if (PIDF->Ps.NUnits > 0) {
    c2idl_PidfUnit((struct PidfUnit *)PIDF->Units,
                   PIDF->Ps.NUnits,
                   (struct s_values_unit*)(arr + sizeof(struct ddd) +
                   sizeof(struct s_values_sensor) * PIDF->Ps.NSensors));
    dims_unit[1] = PIDF->Ps.NUnits;
    s_tags[ntags].name = "PIDF_UNIT";
    s_tags[ntags].dims = dims_unit;
    s_tags[ntags].type = s_unit;
    ++ntags;
  }
  if (PIDF->Ps.NScans > 0) {
    c2idl_PidfScan((struct PidfScan *)PIDF->Scans,
                   PIDF->Ps.NScans,
                   (struct s_values_scan*)(arr + sizeof(struct ddd) +
                   sizeof(struct s_values_sensor) * PIDF->Ps.NSensors +
                   sizeof(struct s_values_unit) * PIDF->Ps.NUnits));
    dims_scan[1] = PIDF->Ps.NScans;
    s_tags[ntags].name = "PIDF_SCAN";
    s_tags[ntags].dims = dims_scan;
    s_tags[ntags].type = s_scan;
    ++ntags;
  }
  if (PIDF->Ps.NModes > 0) {
    c2idl_PidfMode((struct PidfMode *)PIDF->Modes,
                   PIDF->Ps.NModes,
                   (struct s_values_mode*)(arr + sizeof(struct ddd) +
                   sizeof(struct s_values_sensor) * PIDF->Ps.NSensors +
                   sizeof(struct s_values_unit) * PIDF->Ps.NUnits +
                   sizeof(struct s_values_scan) * PIDF->Ps.NScans));
    dims_mode[1] = PIDF->Ps.NModes;
    s_tags[ntags].name = "PIDF_MODE";
    s_tags[ntags].dims = dims_mode;
    s_tags[ntags].type = s_mode;
    ++ntags;
  }
  if (PIDF->Ps.NAncils > 0) {
    c2idl_PidfAnc((struct PidfAnc *)PIDF->Ancil,
                  PIDF->Ps.NAncils,
                  (struct s_values_ancil*)(arr + sizeof(struct ddd) +
                  sizeof(struct s_values_sensor) * PIDF->Ps.NSensors +
                  sizeof(struct s_values_unit) * PIDF->Ps.NUnits +
                  sizeof(struct s_values_scan) * PIDF->Ps.NScans +
                  sizeof(struct s_values_mode) * PIDF->Ps.NModes));
    dims_ancil[1] = PIDF->Ps.NAncils;
    s_tags[ntags].name = "PIDF_ANCIL";
    s_tags[ntags].dims = dims_ancil;
    s_tags[ntags].type = s_ancil;
    ++ntags;
  }

  s_tags[ntags].name = 0;


  s = IDL_MakeStruct(NULL, s_tags);
  return IDL_ImportArray(1, &one, IDL_TYP_STRUCT,
                         (UCHAR*)arr, udf_free, s);
}
