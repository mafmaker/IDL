#include <stdio.h>
#include <stdarg.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <math.h>

#include <export.h>

#include <user_defs.h>
#include <PidfStr.h>
#include <PidfAnsi.h>

#include "udfdlm_ansi.h"
#include "udfdlm_str.h"

void udfdlm_fill_units(ByTe_4 DataField, struct fh_cache *fh)
{
   struct Pidf *P;
   struct PidfSensor *Px;
   struct PidfMode   *Pm;
   struct PidfAnc    *Pa;
   struct PidfScan   *Pi;

   register ByTe_4 *l1;
   register ByTe_2 *s1, *s2;
   register ByTe_1 *c1;

   ByTe_4 N, MaxUnit;
   ByTe_4 Nunits;
   ByTe_4 uN, B;

   P = (struct Pidf *)fh->PIDF;
   Px = (struct PidfSensor *)P->Sensors;
   Pm = (struct PidfMode *)P->Modes;
   Pa = (struct PidfAnc *)P->Ancil;
   Pi = (struct PidfScan *)P->Scans;

   /**********************************************************************/
   /* Nunits is the number of units defined for the sensor               */
   /* unitN  PIDF unit number to use                                     */
   /*                                                                    */
   /* uN must be less than or equal to Nunits                            */
   /* Nunits should be > 0                                               */
   /**********************************************************************/

   MaxUnit = P->Ps.NUnits - 1;

   switch (DataField) {
      case SENSOR:
         s1 = fh->sUnits;
         s2 = fh->sOrder;
         for (N=0; N < fh->TotVSen; N++, ++s1) {
            Nunits = Px[*s2].NUnits;
            if (Nunits < 1)
               idl_barf("sensor %d only has %d units!", N, Nunits);
            uN = RetUnit (fh, *s2, 'S');
            if (uN >= Nunits)  uN = Nunits - 1;
            *s1 = Px[*s2++].Units[uN];
            if (*s1 >= P->Ps.NUnits)
               idl_barf("sensor %d: units(%d) > max=%d!", N, *s1, MaxUnit);
         }
      break;
      case MODE:
         s1 = fh->mUnits;
         for (N=0; N < P->Ps.NModes; N++, ++s1) {
            Nunits = Pm[N].NUnits;
            if (Nunits < 1)
               idl_barf("sensor %d only has %d units!", N, Nunits);
            uN = RetUnit (fh, *s2, 'M');
            if (uN >= Nunits)  uN = Nunits - 1;
            *s1 = Pm[N].Units[uN];
            if (*s1 >= P->Ps.NUnits)
               idl_barf("sensor %d: units(%d) > max=%d!", N, *s1, MaxUnit);
         }
      break;
      case ANCILLARY:
         s1 = fh->aUnits;
         s2 = fh->aOrder;
         c1 = fh->aLoc;
         for (N=0; N < fh->TotAnc; N++, ++s1) {
            Nunits = (*c1 == 'A') ? Pa[*s2].NUnits : Px[*s2].NUnits;
            if (Nunits < 1)
               idl_barf("sensor %d only has %d units!", N, Nunits);
            uN = RetUnit (fh, *s2, *c1);
            if (uN >= Nunits)  uN = Nunits - 1;
            *s1 = (*c1++ == 'A') ? Pa[*s2++].Units[uN] : Px[*s2++].Units[uN];
            if (*s1 >= P->Ps.NUnits)
               idl_barf("sensor %d: units(%d) > max=%d!", N, *s1, MaxUnit);
         }
      break;
      case SCAN_INDEX:
         fh->arUnits = Pi[0].Units[0];
         if (fh->tV > 0) {
            B = sizeof (ByTe_4);
            l1 = (ByTe_4 *)fh->pInfo;
            s1 = (ByTe_2 *)(fh->pInfo + fh->tV * B);
            B += sizeof (ByTe_2);
            c1 = (ByTe_1 *)(fh->pInfo + fh->tV * B);
            for (N = 0; N < fh->tV; ++N, ++l1, ++s1) {
               if (*c1++ == 'I') {
                  fh->arUnits = Pi[*l1].Units[*s1];
                  break;
               }
            }
         }
         
      break;
   }
}
