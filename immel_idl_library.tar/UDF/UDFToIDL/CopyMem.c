#include <stdio.h>
#include <stdarg.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <math.h>

#include <export.h>

#include "udfdlm_defs.h"
#include "udfdlm_ansi.h"

void CopyMem (ByTe_1 *IdL, void *UdF, ByTe_4 N, ByTe_1 Precision)
{
   register float *f1;
   register ReaL_4 *f2, *fEnD;
   register double *d1;
   register ReaL_8 *d2, *dEnD;

   if (Precision == sizeof(ReaL_4)) {
      f1 = (float *)IdL;
      f2 = (ReaL_4 *)UdF;
      fEnD = f2 + N;

      for ( ; f2 < fEnD;)
         *f1++ = *f2++;
   } else {
      d1 = (double *)IdL;
      d2 = (ReaL_8 *)UdF;
      dEnD = d2 + N;

      for ( ; d2 < dEnD;)
         *d1++ = *d2++;
   } 
}
