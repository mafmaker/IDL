#include <stdio.h>
#include <stdarg.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <math.h>

#include <export.h>

#include <local_defs.h>
#include <user_defs.h>
#include <idf_defs.h>
#include <DbDefs.h>
#include <ret_codes.h>
#include <libbase_udf.h>
#include <PidfAnsi.h>
#include <PidfStr.h>
#include <PidfRets.h>
#include <libCfg.h>
#include <StrHier.h>
#include <dbf.h>

#include "udfdlm_defs.h"
#include "udfdlm_ansi.h"
#include "udf.h"

/**************************\
|*  udfdlm_post_idl_load  *|  automatically invoked after IDL_Load(), for init
\**************************/

int udfdlm_post_idl_load( void )
{
   extern void *s_udf_time;
   extern void *s_udf_times;
   extern u_ByTe_2 Version;
   extern ByTe_1 Ext[];
   
   extern IDL_STRUCT_TAG_DEF s_tags_udf_time[];
   extern IDL_STRUCT_TAG_DEF s_tags_udf_times[];

   Ext[0] = 0;
   Ext[1] = 0;
   Ext[2] = 0;
   init_udf();				/* Must be done before anything */
   get_version_number(&Version);        /* Initialize the "Version" global */

  /*
  ** Define the UDF_TIME and UDF_TIMES (plural) data structures
  */

   s_udf_time  = IDL_MakeStruct("UDF_TIME",  s_tags_udf_time);	/* DLM */

   s_tags_udf_times[0].type = s_udf_time;
   s_tags_udf_times[1].type = s_udf_time;
   s_udf_times = IDL_MakeStruct("UDF_TIMES", s_tags_udf_times);	/* DLM */

   return 1;				/* Should we check error status? */
}
