/*
** udf.h  --  header stuff for UDF package
**
*/

#ifndef	__UDF_DLM_STR_H
#define	__UDF_DLM_STR_H 1

/*
** for the filehandle cache we keep
*/

struct fh_cache {
  u_ByTe_4    Key;		/* Key; identifies proj/miss/../vinst	*/
  ByTe_1      BaseName[80];	/* Base Name of V.Inst (for struct def)	*/
  ByTe_2      LastRead;         /* Status of the last read_drec call    */
  ByTe_2      is_open;		/* UDF doesn't like multiple opens	*/
  ByTe_2      Ey;               /* requested ending year                */
  ByTe_2      Ed;               /* requested ending day                 */
  ByTe_4      Ems;              /* requested ending millisecond         */
  ByTe_2      tV;               /* total opt values recovered           */
  u_ByTe_1    sample_id;	/* 1,2 == regular; 3 == matrix		*/
  u_ByTe_1    sen_mode;         /* time flow indicator                  */
  u_ByTe_1    nanc;             /* num of VIDF defined ancillary sets   */
  u_ByTe_2    maxlen;		/* Max. vector length of any sensor	*/
  ByTe_2      TotVSen;		/* Total number of VIDF sensor defs     */
  ByTe_2      TotAnc;		/* Total number of ANC definitions      */
  ByTe_2      TotMode;	        /* Total number of modes definitions    */
  ByTe_2      TotIndex;         /* Total array index definitions        */
  ByTe_4      dSize;            /* total size to malloc() for data      */
  ByTe_4      MyChoice;         /* Temporary Variable                   */
  ByTe_4      sType;            /* IDL variable type used by data       */
  ByTe_2      *Order;	        /* What order to read sensors           */
  ByTe_2      *Units;	        /* What "units" to "convert" to		*/
  ByTe_1      *Set;	        /* Anc Data set numbers                 */
  ByTe_1      *Loc;	        /* Where the Anc definition is in PIDF  */
  ByTe_1      *uNDef;	        /* Units: 0, 1of1; 1, 1of2; 2 2of2      */
  ByTe_1      *Dim;	        /* Dimension of Anc (Scalar or Array)   */
  ByTe_4      NCols;            /* Number of columns in each "matrix"   */
  ByTe_4      *Begs;            /* Byte offset to each data definition  */

  void        *AncInfo;		/* VIDF ancillary data set info         */
  void        *PIDF;		/* PIDF structure definition		*/
  void        *dA;              /* structure data area                  */
  void        *pInfo;           /* unit Information from menu           */
  void        *sdef;		/* IDL sensor structure definition	*/
  struct {
    UCHAR  sformat;
    UCHAR  azimuth;
    UCHAR  theta;
    UCHAR  indices;
    UCHAR  dformat;
    UCHAR  baseunit;
  } flags;
};

struct udf_time {                       /* This must be identical to */
  short          year;                  /* the IDL structure below   */
  unsigned short doy;
  unsigned char  hour;
  unsigned char  min;
  unsigned char  sec;
  unsigned short msec;
  double         dp;
};

struct udf_times {
  struct udf_time btime;
  struct udf_time etime;
};

#endif	/* __UDF_DLM_STR_H */
