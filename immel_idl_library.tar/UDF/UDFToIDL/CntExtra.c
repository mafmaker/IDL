#include <stdio.h>
#include <stdarg.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <math.h>

#include <export.h>

#include <user_defs.h>
#include <PidfStr.h>
#include <PidfAnsi.h>

#include "udfdlm_ansi.h"
#include "udfdlm_str.h"

ByTe_4 CntExtra (struct fh_cache *fh, ByTe_1 Src)
{
    struct Pidf *P;
    struct PidfSensor *Px;

    register ByTe_4 *l1;
    register ByTe_2 *s1, *s2;
    register ByTe_1 *c1;

    ByTe_4 N, Tot = 0, B;

    B = sizeof (ByTe_4);
    s1 = (ByTe_2 *)(fh->pInfo + fh->tV * B);
    B += sizeof (ByTe_2);
    s2 = (ByTe_2 *)(fh->pInfo + fh->tV * B);

    if (Src == 'T')
    {
       for (N = 0; N < fh->tV; ++N, ++s1, ++s2, ++c1)
             Tot += (*s1 == *s2) ? 0 : 1;
    } 
    else
    {
       P = (struct Pidf *)fh->PIDF;
       Px = (struct PidfSensor *)P->Sensors;

       B += sizeof (ByTe_2);
       l1 = (ByTe_4 *)fh->pInfo;
       c1 = (ByTe_1 *)(fh->pInfo + fh->tV * B);

       switch (Src) {
          case 'S':
            for (N=0; N < fh->tV; ++N, ++s1, ++s2, ++l1) {
               if (*c1++ == 'S') {
                  if (Px[*l1].Src == 'V') {
                     Tot += (*s1 == *s2) ? 0 : 1;
                  }
               }
            }
          break;
          case 'A':
            for (N=0; N < fh->tV; ++N, ++s1, ++s2, ++l1) {
               if (*c1++ == 'S') {
                  if (Px[*l1].Src == 'A') {
                     Tot += (*s1 == *s2) ? 0 : 1;
                  }
               } else {
                  if (*c1++ == 'A')
                     Tot += (*s1 == *s2) ? 0 : 1;
               }
            }
          break;
          case 'I':
          case 'M':
             for (N = 0; N < fh->tV; ++N, ++s1, ++s2, ++c1)
             {
                if (*c1 == Src) 
                   Tot += (*s1 == *s2) ? 0 : 1;
             }
          break;
       }
    } 

    return (Tot);
}
