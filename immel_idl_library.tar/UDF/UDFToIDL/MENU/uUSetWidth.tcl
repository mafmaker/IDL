proc uUSetWidth { Opts } {

   set Len [llength $Opts]
   set MaxL 1
   for {set J 0} {$J < $Len} {incr J} {
       set SLen [string length [lindex $Opts $J]]
       if {$SLen > $MaxL} {set MaxL $SLen }
   }

   return $MaxL
}

