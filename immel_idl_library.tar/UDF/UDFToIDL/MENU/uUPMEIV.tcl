proc uUPMEIV { } {
    global env SyS PROJECTS DbRead DbPaths lineage

    if {$DbRead == 0 } { GM_GetDbInfo }

    set W .inMAIN.left

    set Ops ""
    if { [string length $SyS(PROJECT)] == 0 } {
       set Wb $W.project.b
       set R PROJECTS
       global [set R]
       GM_MButton $Wb "" 0 0 0 0 [set $R] "uUProcOpt $Wb PROJECT"
    } 

    if { [string length $SyS(PROJECT)] != 0 } {
       set Wb $W.mission.b
       set R $SyS(PROJECT)
       global [set R]
       GM_MButton $Wb "" 0 0 0 0 [set $R] "uUProcOpt $Wb MISSION"
    }

    if { [string length $SyS(PROJECT)] != 0 } {
       if { [string length $SyS(MISSION)] != 0 } {
          set Wb $W.experiment.b
          set R $SyS(PROJECT).$SyS(MISSION)
          global [set R]
          GM_MButton $Wb "" 0 0 0 0 [set $R] "uUProcOpt $Wb EXPERIMENT"
       }
    } 

    if { [string length $SyS(PROJECT)] != 0 } {
       if { [string length $SyS(MISSION)] != 0 } {
           if { [string length $SyS(EXPERIMENT)] != 0 } {
              set Wb $W.instrument.b
              set R $SyS(PROJECT).$SyS(MISSION).$SyS(EXPERIMENT)
              global [set R]
              GM_MButton $Wb "" 0 0 0 0 [set $R] "uUProcOpt $Wb INSTRUMENT"
          }   
       }
    } 

    if { [string length $SyS(PROJECT)] != 0 } {
       if { [string length $SyS(MISSION)] != 0 } {
           if { [string length $SyS(EXPERIMENT)] != 0 } {
              if { [string length $SyS(INSTRUMENT)] != 0 } {
                 set Wb $W.virtual.b
                 set R $SyS(PROJECT).$SyS(MISSION).$SyS(EXPERIMENT).$SyS(INSTRUMENT)
                 global [set R]
                 GM_MButton $Wb "" 0 0 0 0 [set $R] "uUProcOpt $Wb VIRTUAL"
              }
           }   
       }
    } 
}
