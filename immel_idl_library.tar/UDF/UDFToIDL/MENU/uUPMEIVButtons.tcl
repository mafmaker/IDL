proc uUPMEIVButtons { } {
   global env SyS lineage DefMenu 
   
   set W .inMAIN.left

   if { [winfo exists $W.project] == 0 } {

      set len [llength $lineage]
      for {set i 0} { $i < $len } { incr i } {
          set FIELD [lindex $lineage $i]
          set field [string tolower $FIELD]

          set Wf "$W.$field"
          GM_Frame $Wf 0
          pack $Wf -side top -ipady 10
          set Wl $Wf.l
          GM_Label $Wl $FIELD 1 center false top 
          set Wb $Wf.b
          if { $DefMenu == 0 } { set SyS($FIELD) "" }
          GM_MButton $Wb "" 1 0 false top "" "" 10 1 14 uUPMEIV
          if { $DefMenu == 1 } {
             $Wb configure -text $SyS($FIELD) -font default
          }
      }
   }
}
