proc uUProcOpt { W elem Pos } {
   global env SyS SySN lineage PaGeS DefMenu
   
   set Wm $W.menu
   set SySN($elem) $Pos
   set SyS($elem) [$Wm entrycget $Pos -label]
   $W configure -text $SyS($elem)

   set len [llength $lineage]
   for {set i 0} { $i < $len } { incr i } {
      set FIELD [lindex $lineage $i]
      set field [string tolower $FIELD]
      if { [string match $elem $FIELD] == 1 } {
         set j [expr $i + 1]
         for {set j [expr $i + 1]} { $j < $len } { incr j } {
            set SUBFIELD [lindex $lineage $j]
            set subfield [string tolower $SUBFIELD]
            set SyS($SUBFIELD) "" 
            set SySN($SUBFIELD) "" 
            regsub $field $W $subfield nW
            set dW $nW.menu
            $dW delete 0 end
            $nW configure -text $SyS($SUBFIELD)
         }
         set i $len
      }
   }

   set DefMenu 0
   for {set i 0} { $i < $PaGeS } { incr i } {
       destroy .pg$i
       destroy .inMAIN.right.pg$i
   }
}
