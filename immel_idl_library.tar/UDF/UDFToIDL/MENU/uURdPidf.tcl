proc uURdPidf { } {
   global env SyS PaGeS MaxPerPage PIDFRead PNum MLoc TotItems DefMenu \
          WNumb WNumc PIDFnumunits PIDFunitLdes PIDFunitlab \
          PIDFnumsens PIDFsenunits PIDFsenNunits PIDFsenname PIDFsensource \
          PIDFnummodes PIDFmodeunits PIDFmodeNunits PIDFmodename \
          PIDFsenpidfN PIDFmodepidfN PIDFancpidfN \
          PIDFnumancs PIDFancunits PIDFancNunits PIDFancname \
          PIDFnumscans PIDFscanNunits PIDFscanunits

   if {$DefMenu == 1 } { return }

   set DefMenu 1
   set Fn [GM_PidfPath $SyS(PROJECT) $SyS(MISSION) \
                   $SyS(EXPERIMENT) $SyS(INSTRUMENT) $SyS(VIRTUAL) ]

   if {[string compare $PIDFRead $Fn] != 0} {GM_ReadPIDF $Fn}
 
   set wN .inTOPb.a.b
   set DefUnits [$wN.menu index [$wN cget -text]]

   set W .inMAIN.right
   set Pos  0
   set TotItems  0

   set TPgs [expr int ($PIDFnumsens / $MaxPerPage)] 
   set Rem [expr $PIDFnumsens % $MaxPerPage] 
   if {$Rem == 0 } {incr TPgs -1 }

   for {set M 0 } { $M <= $TPgs } {incr M } {
      set pN .pg$PaGeS
      toplevel $pN
      set Lab "SENSOR Page $M"
      wm title $pN $Lab
      wm withdraw $pN 
      GM_Frame $pN.top
      GM_Frame $pN.main
      pack $pN.top $pN.main -side top -fill x
 
      GM_Button $W$pN $Lab 0 $PaGeS 0 e "wm deiconify $pN" 
      GM_Button $pN.top.bc CLOSE 1 0 false right "wm withdraw $pN" 10 

      set I 0
      while {($I < $MaxPerPage) && ($Pos < $PIDFnumsens)} {
         set wN $pN.main.l$I
         GM_Label $wN $PIDFsenname($Pos) 0 $I 0 w 
         set wNb $pN.main.b$I
         set wNc $pN.main.c$I
         set nU $PIDFsenNunits($Pos)
         set uNames ""
         for {set J 0 } { $J < $nU } {incr J } {
           set uN [lindex $PIDFsenunits($Pos) $J] 
           lappend uNames "$PIDFunitLdes($uN) : $PIDFunitlab($uN)"
         }
         GM_MButton $wNb "" 0 $I 1 w $uNames "ProcOpts $wNb" 10 1 40
         GM_MButton $wNc "" 0 $I 2 w $uNames "ProcOpts $wNc" 10 1 40

         if { $DefUnits == 0 } {
            set uN [lindex $PIDFsenunits($Pos) 0] 
            set Lab "$PIDFunitLdes($uN) : $PIDFunitlab($uN)"
         } else {
            set uN [lindex $PIDFsenunits($Pos) [expr $nU - 1]] 
            set Lab "$PIDFunitLdes($uN) : $PIDFunitlab($uN)"
         }
         $wNb configure -text $Lab -font default
         $wNc configure -text $Lab -font default
         set PNum($TotItems) $PIDFsenpidfN($Pos)
         set WNumb($TotItems) $wNb
         set WNumc($TotItems) $wNc
         set MLoc($TotItems) S

         incr I
         incr Pos
         incr TotItems
      }
      incr PaGeS
   }

   if { $PIDFnummodes > 0 } {
      set TPgs [expr int ($PIDFnummodes / $MaxPerPage)] 
      set Rem [expr $PIDFnummodes % $MaxPerPage] 
      if {$Rem == 0 } {incr TPgs -1 }
      set Pos  0

      for {set M 0 } { $M <= $TPgs } {incr M } {
         set pN .pg$PaGeS
         toplevel $pN
         set Lab "MODE Page $M"
         wm title $pN $Lab
         wm withdraw $pN 
         GM_Frame $pN.top
         GM_Frame $pN.main
         pack $pN.top $pN.main -side top -fill x
   
         GM_Button $W$pN $Lab 0 $PaGeS 0 e "wm deiconify $pN" 
         GM_Button $pN.top.bc CLOSE 1 0 false right "wm withdraw $pN" 10 

         set I 0
         while {($I < $MaxPerPage) && ($Pos < $PIDFnummodes)} {
             set wN $pN.main.l$I
             GM_Label $wN $PIDFmodename($Pos) 0 $I 0 w 
             set wNb $pN.main.b$I
             set wNc $pN.main.c$I
   
             set nU $PIDFmodeNunits($Pos)
             set uNames ""
             for {set J 0 } { $J < $nU } {incr J } {
               set uN [lindex $PIDFmodeunits($Pos) $J] 
               lappend uNames "$PIDFunitLdes($uN) : $PIDFunitlab($uN)"
             }
             GM_MButton $wNb "" 0 $I 1 w $uNames "ProcOpts $wNb" 10 1 40
             GM_MButton $wNc "" 0 $I 2 w $uNames "ProcOpts $wNc" 10 1 40

             if { $DefUnits == 0 } {
                set uN [lindex $PIDFmodeunits($Pos) 0] 
                set Lab "$PIDFunitLdes($uN) : $PIDFunitlab($uN)"
             } else {
                set uN [lindex $PIDFmodeunits($Pos) [expr $nU - 1]] 
                set Lab "$PIDFunitLdes($uN) : $PIDFunitlab($uN)"
             }
             $wNb configure -text $Lab -font default
             $wNc configure -text $Lab -font default
             set PNum($TotItems) $PIDFmodepidfN($Pos)
             set WNumb($TotItems) $wNb
             set WNumc($TotItems) $wNc
             set MLoc($TotItems) M
   
             incr I
             incr Pos
             incr TotItems
          }
          incr PaGeS
       }
   }

   if {$PIDFnumancs > 0} {
      set TPgs [expr int ($PIDFnumancs / $MaxPerPage)] 
      set Rem [expr $PIDFnumancs % $MaxPerPage] 
      if {$Rem == 0 } {incr TPgs -1 }
      set Pos  0

      for {set M 0 } { $M <= $TPgs } {incr M } {
         set pN .pg$PaGeS
         toplevel $pN
         set Lab "ANCILLARY Page $M"
         wm title $pN $Lab
         wm withdraw $pN 
         GM_Frame $pN.top
         GM_Frame $pN.main
         pack $pN.top $pN.main -side top -fill x

         GM_Button $W$pN $Lab 0 $PaGeS 0 e "wm deiconify $pN" 
         GM_Button $pN.top.bc CLOSE 1 0 false right "wm withdraw $pN" 10 

         set I 0
         while {($I < $MaxPerPage) && ($Pos < $PIDFnumancs)} {
             set wN $pN.main.l$I
             GM_Label $wN $PIDFancname($Pos) 0 $I 0 w 
             set wNb $pN.main.b$I
             set wNc $pN.main.c$I

             set nU $PIDFancNunits($Pos)
             set uNames ""
             for {set J 0 } { $J < $nU } {incr J } {
               set uN [lindex $PIDFancunits($Pos) $J] 
               lappend uNames "$PIDFunitLdes($uN) : $PIDFunitlab($uN)"
             }
             GM_MButton $wNb "" 0 $I 1 w $uNames "ProcOpts $wNb" 10 1 40
             GM_MButton $wNc "" 0 $I 2 w $uNames "ProcOpts $wNc" 10 1 40

             if { $DefUnits == 0 } {
                set uN [lindex $PIDFancunits($Pos) 0] 
                set Lab "$PIDFunitLdes($uN) : $PIDFunitlab($uN)"
             } else {
                set uN [lindex $PIDFancunits($Pos) [expr $nU - 1]] 
                set Lab "$PIDFunitLdes($uN) : $PIDFunitlab($uN)"
             }
             $wNb configure -text $Lab -font default
             $wNc configure -text $Lab -font default
             set PNum($TotItems) $PIDFancpidfN($Pos)
             set WNumb($TotItems) $wNb
             set WNumc($TotItems) $wNc
             set MLoc($TotItems) A
   
             incr I
             incr Pos
             incr TotItems
          }
          incr PaGeS
       }
   }

   if {$PIDFnumscans > 0} {
      set pN .pg$PaGeS
      toplevel $pN
      set Lab "ARRAY INDICES"
      wm title $pN $Lab
      wm withdraw $pN 
      GM_Frame $pN.top
      GM_Frame $pN.main
      pack $pN.top $pN.main -side top -fill x

      GM_Button $W$pN $Lab 0 $PaGeS 0 e "wm deiconify $pN" 
      GM_Button $pN.top.bc CLOSE 1 0 false right "wm withdraw $pN" 10 

      set wN $pN.main.l0
      GM_Label $wN "Array Index" 0 0 0 w 
      set wNb $pN.main.b0
      set wNc $pN.main.c0

      set nU $PIDFscanNunits(0)
      set uNames ""
      for {set J 0 } { $J < $nU } {incr J } {
          set uN [lindex $PIDFscanunits(0) $J] 
          lappend uNames "$PIDFunitLdes($uN) : $PIDFunitlab($uN)"
      }
      GM_MButton $wNb "" 0 0 1 w $uNames "ProcOpts $wNb" 10 1 40
      GM_MButton $wNc "" 0 0 2 w $uNames "ProcOpts $wNc" 10 1 40

      if { $DefUnits == 0 } {
          set uN [lindex $PIDFscanunits(0) 0]
          set Lab "$PIDFunitLdes($uN) : $PIDFunitlab($uN)"
      } else {
          set uN [lindex $PIDFscanunits(0) [expr $nU - 1]]
          set Lab "$PIDFunitLdes($uN) : $PIDFunitlab($uN)"
      }
      $wNb configure -text $Lab -font default
      $wNc configure -text $Lab -font default
      set PNum($TotItems) 0
      set WNumb($TotItems) $wNb
      set WNumc($TotItems) $wNc
      set MLoc($TotItems) I
   
      incr TotItems
      incr PaGeS
   }
}
