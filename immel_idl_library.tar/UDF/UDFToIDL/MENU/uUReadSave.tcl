proc uUReadSave { } {
   global SyS SaveName PNum MLoc PIDFnumsens PIDFnummodes PIDFnumancs \
          UNumb UNumc DefMenu TotItems DefU DefSs DefTh DefAi DefAz DefDf

   set DefMenu 0
   set Cntr 0
   set DefU 0
   set DefSs 0
   set DefDf 0
   set DefTh 0
   set DefAz 0
   set DefAi 0

   if [file exists $SaveName] {
      if ![catch {open $SaveName r} rFd ] {
         if { [gets $rFd line] >= 0 } {
            set SyS(PROJECT)    [lindex [split $line ] 0]
            set SyS(MISSION)    [lindex [split $line ] 1]
            set SyS(EXPERIMENT) [lindex [split $line ] 2]
            set SyS(INSTRUMENT) [lindex [split $line ] 3]
            set SyS(VIRTUAL)    [lindex [split $line ] 4]
         }
 
         if { [gets $rFd line] >= 0 } { set Items  $line }
         if { $Cntr < $Items } { 
            if { [gets $rFd line] >= 0 } { set DefU  $line }
         } 
         incr Cntr
         if { $Cntr < $Items } { 
            if { [gets $rFd line] >= 0 } { set DefSs $line }
         }
         incr Cntr
         if { $Cntr < $Items } { 
            if { [gets $rFd line] >= 0 } { set DefDf $line }
         }
         incr Cntr
         if { $Cntr < $Items } { 
            if { [gets $rFd line] >= 0 } { set DefAz $line }
         }
         incr Cntr
         if { $Cntr < $Items } { 
            if { [gets $rFd line] >= 0 } { set DefTh $line }
         }
         incr Cntr
         if { $Cntr < $Items } { 
            if { [gets $rFd line] >= 0 } { set DefAi $line }
         }
         incr Cntr
         
         if { [gets $rFd line] >= 0 } { set TotItems $line }
         for {set I 0} {$I < $TotItems} {incr I} {
            if { [gets $rFd line] >= 0 } {
               set PNum($I) [lindex [split $line ] 0]
               set MLoc($I) [lindex [split $line ] 1]
               set UNumb($I) [lindex [split $line ] 2]
               set UNumc($I) [lindex [split $line ] 3]
            }
         }
         close $rFd
         set DefMenu 1
      }
   }
}

