proc uUFillIn { } {
   global env SyS PaGeS MaxPerPage PIDFRead UNumb UNumc PNum MLoc TotItems \
          WNumb WNumc PIDFnumunits PIDFunitLdes PIDFunitlab \
          PIDFnumsens PIDFsenunits PIDFsenNunits PIDFsenname PIDFsensource \
          PIDFnummodes PIDFmodeunits PIDFmodeNunits PIDFmodename \
          PIDFsenpidfN PIDFmodepidfN PIDFancpidfN \
          PIDFnumancs PIDFancunits PIDFancNunits PIDFancname \
          PIDFnumscans PIDFscanNunits PIDFscanunits

   set Fn [GM_PidfPath $SyS(PROJECT) $SyS(MISSION) \
                   $SyS(EXPERIMENT) $SyS(INSTRUMENT) $SyS(VIRTUAL) ]

   if {[string compare $PIDFRead $Fn] != 0} {GM_ReadPIDF $Fn}


   set W .inMAIN.right

   set Pos    0
   set Total  0
   set TotVSen  0
   set TotMSen  0
   set TotASen  0
   set TotISen  0

   for {set M 0 } { $M < $TotItems } {incr M } {
       if {[string match $MLoc($M) S] == 1 } { incr TotVSen }
   }

   set TPgs [expr int ($TotVSen / $MaxPerPage)] 
   set Rem [expr $TotVSen % $MaxPerPage] 
   if {$Rem == 0 } {incr TPgs -1 }
   for {set M 0 } { $M <= $TPgs } {incr M } {
      set pN .pg$PaGeS
      toplevel $pN
      set Lab "SENSOR Page $M"
      wm title $pN $Lab
      wm withdraw $pN 
      GM_Frame $pN.top
      GM_Frame $pN.main
      pack $pN.top $pN.main -side top -fill x
 
      GM_Button $W$pN $Lab 0 $PaGeS 0 e "wm deiconify $pN" 
      GM_Button $pN.top.bc CLOSE 1 0 false right "wm withdraw $pN" 10 

      set I 0
      while {($I < $MaxPerPage) && ($Pos < $TotItems)} {
         if {[string match $MLoc($Pos) S] == 1 } {
            set NuM $PNum($Pos) 
            set wN $pN.main.l$I
            GM_Label $wN $PIDFsenname($NuM) 0 $I 0 w 
            set wNb $pN.main.b$I
            set wNc $pN.main.c$I
            set nU $PIDFsenNunits($NuM)
            set uNames ""
            for {set J 0 } { $J < $nU } {incr J } {
              set uN [lindex $PIDFsenunits($NuM) $J] 
              lappend uNames "$PIDFunitLdes($uN) : $PIDFunitlab($uN)"
            }
            GM_MButton $wNb "" 0 $I 1 w $uNames "ProcOpts $wNb" 10 1 40
            GM_MButton $wNc "" 0 $I 2 w $uNames "ProcOpts $wNc" 10 1 40

            set uN [lindex $PIDFsenunits($NuM) $UNumb($Pos)] 
            set Lab "$PIDFunitLdes($uN) : $PIDFunitlab($uN)"
            $wNb configure -text $Lab -font default
            set uN [lindex $PIDFsenunits($NuM) $UNumc($Pos)] 
            set Lab "$PIDFunitLdes($uN) : $PIDFunitlab($uN)"
            $wNc configure -text $Lab -font default
            set WNumb($Total) $wNb
            set WNumc($Total) $wNc

            incr I
            incr Total
         }
         incr Pos
      }
      incr PaGeS
   }

   set Pos  0
   for {set M 0 } { $M < $TotItems } {incr M } {
       if {[string match $MLoc($M) M] == 1 } { incr TotMSen }
   }

   if {$TotMSen > 0} { 
      set TPgs [expr int ($TotMSen / $MaxPerPage)] 
      set Rem [expr $TotMSen % $MaxPerPage] 
      if {$Rem == 0 } {incr TPgs -1 }

      for {set M 0 } { $M <= $TPgs } {incr M } {
         set pN .pg$PaGeS
         toplevel $pN
         set Lab "MODE Page $M"
         wm title $pN $Lab
         wm withdraw $pN 
         GM_Frame $pN.top
         GM_Frame $pN.main
         pack $pN.top $pN.main -side top -fill x
 
         GM_Button $W$pN $Lab 0 $PaGeS 0 e "wm deiconify $pN" 
         GM_Button $pN.top.bc CLOSE 1 0 false right "wm withdraw $pN" 10 

         set I 0
         while {($I < $MaxPerPage) && ($Pos < $TotItems)} {
            if {[string match $MLoc($Pos) M] == 1 } {
               set NuM $PNum($Pos) 
               set wN $pN.main.l$I
               GM_Label $wN $PIDFmodename($NuM) 0 $I 0 w 
               set wNb $pN.main.b$I
               set wNc $pN.main.c$I
               set nU $PIDFmodeNunits($NuM)
               set uNames ""
               for {set J 0 } { $J < $nU } {incr J } {
                 set uN [lindex $PIDFmodeunits($NuM) $J] 
                 lappend uNames "$PIDFunitLdes($uN) : $PIDFunitlab($uN)"
               }
               GM_MButton $wNb "" 0 $I 1 w $uNames "ProcOpts $wNb" 10 1 40
               GM_MButton $wNc "" 0 $I 2 w $uNames "ProcOpts $wNc" 10 1 40

               set uN [lindex $PIDFmodeunits($NuM) $UNumb($Pos)] 
               set Lab "$PIDFunitLdes($uN) : $PIDFunitlab($uN)"
               $wNb configure -text $Lab -font default
               set uN [lindex $PIDFmodeunits($NuM) $UNumc($Pos)] 
               set Lab "$PIDFunitLdes($uN) : $PIDFunitlab($uN)"
               $wNc configure -text $Lab -font default
               set WNumb($Total) $wNb
               set WNumc($Total) $wNc

               incr I
               incr Total
            }
            incr Pos
         }
         incr PaGeS
      }
   }

   set Pos  0
   for {set M 0 } { $M < $TotItems } {incr M } {
       if {[string match $MLoc($M) A] == 1 } { incr TotASen }
   }

   if {$TotASen > 0} { 
      set TPgs [expr int ($TotASen / $MaxPerPage)] 
      set Rem [expr $TotASen % $MaxPerPage] 
      if {$Rem == 0 } {incr TPgs -1 }

      for {set M 0 } { $M <= $TPgs } {incr M } {
         set pN .pg$PaGeS
         toplevel $pN
         set Lab "ANCILLARY Page $M"
         wm title $pN $Lab
         wm withdraw $pN 
         GM_Frame $pN.top
         GM_Frame $pN.main
         pack $pN.top $pN.main -side top -fill x
 
         GM_Button $W$pN $Lab 0 $PaGeS 0 e "wm deiconify $pN" 
         GM_Button $pN.top.bc CLOSE 1 0 false right "wm withdraw $pN" 10 
   
         set I 0
         while {($I < $MaxPerPage) && ($Pos < $TotItems)} {
            if { [string match $MLoc($Pos) A] == 1 } {
               set NuM $PNum($Pos) 
               set wN $pN.main.l$I
               GM_Label $wN $PIDFancname($NuM) 0 $I 0 w 
               set wNb $pN.main.b$I
               set wNc $pN.main.b$I
               set nU $PIDFancNunits($NuM)
               set uNames ""
               for {set J 0 } { $J < $nU } {incr J } {
                 set uN [lindex $PIDFancunits($NuM) $J] 
                 lappend uNames "$PIDFunitLdes($uN) : $PIDFunitlab($uN)"
               }
               GM_MButton $wNb "" 0 $I 1 w $uNames "ProcOpts $wNb" 10 1 40
               GM_MButton $wNc "" 0 $I 2 w $uNames "ProcOpts $wNc" 10 1 40

               set uN [lindex $PIDFancunits($NuM) $UNumb($Pos)] 
               set Lab "$PIDFunitLdes($uN) : $PIDFunitlab($uN)"
               $wNb configure -text $Lab -font default
               set uN [lindex $PIDFancunits($NuM) $UNumc($Pos)] 
               set Lab "$PIDFunitLdes($uN) : $PIDFunitlab($uN)"
               $wNc configure -text $Lab -font default
               set WNumb($Total) $wNb
               set WNumc($Total) $wNc

               incr I
               incr Total
            }
            incr Pos
         }
         incr PaGeS
      }
   }

   set Pos  0
   for {set M 0 } { $M < $TotItems } {incr M } {
       if {[string match $MLoc($M) I] == 1 } { incr TotISen }
   }

   if {$TotISen > 0} { 
      set pN .pg$PaGeS
      toplevel $pN
      set Lab "ARRAY INDICES"
      wm title $pN $Lab
      wm withdraw $pN 
      GM_Frame $pN.top
      GM_Frame $pN.main
      pack $pN.top $pN.main -side top -fill x
 
      GM_Button $W$pN $Lab 0 $PaGeS 0 e "wm deiconify $pN" 
      GM_Button $pN.top.bc CLOSE 1 0 false right "wm withdraw $pN" 10 
   
      set Pos 0
      while {$Pos < $TotItems} {
         if { [string match $MLoc($Pos) I] == 1 } {
            set NuM $PNum($Pos) 
            set wN $pN.main.l0
            GM_Label $wN "Array Index" 0 0 0 w 
            set wNb $pN.main.b0
            set wNc $pN.main.c0
            set nU $PIDFscanNunits($NuM)
            set uNames ""
            for {set J 0 } { $J < $nU } {incr J } {
                set uN [lindex $PIDFscanunits($NuM) $J] 
                lappend uNames "$PIDFunitLdes($uN) : $PIDFunitlab($uN)"
            }
            GM_MButton $wNb "" 0 0 1 w $uNames "ProcOpts $wNb" 10 1 40
            GM_MButton $wNc "" 0 0 2 w $uNames "ProcOpts $wNc" 10 1 40

            set uN [lindex $PIDFscanunits($NuM) $UNumb($Pos)] 
            set Lab "$PIDFunitLdes($uN) : $PIDFunitlab($uN)"
            $wNb configure -text $Lab -font default
            set uN [lindex $PIDFscanunits($NuM) $UNumc($Pos)] 
            set Lab "$PIDFunitLdes($uN) : $PIDFunitlab($uN)"
            $wNc configure -text $Lab -font default
            set WNumb($Total) $wNb
            set WNumc($Total) $wNc

            incr Total
         }
         incr Pos
      }
      incr PaGeS
   }
}
