proc uUSave { } {
  global SyS SaveName WNumb WNumc PNum MLoc TotItems

  if ![catch {open $SaveName w} rFd ] {
     puts $rFd "$SyS(PROJECT) $SyS(MISSION) $SyS(EXPERIMENT)\
                $SyS(INSTRUMENT) $SyS(VIRTUAL)"

     set wN .inTOPb
     puts $rFd 6
     puts $rFd "[$wN.a.b.menu index [$wN.a.b cget -text]]"
     puts $rFd "[$wN.b.b.menu index [$wN.b.b cget -text]]"
     puts $rFd "[$wN.c.b.menu index [$wN.c.b cget -text]]"
     puts $rFd "[$wN.d.b.menu index [$wN.d.b cget -text]]"
     puts $rFd "[$wN.e.b.menu index [$wN.e.b cget -text]]"
     puts $rFd "[$wN.f.b.menu index [$wN.f.b cget -text]]"
     puts $rFd $TotItems

     for {set I 0} {$I < $TotItems} {incr I} {
         set wNb $WNumb($I)
         set wNc $WNumc($I)
         set Ib [$wNb.menu index [$wNb cget -text]]
         set Ic [$wNc.menu index [$wNc cget -text]]
         puts $rFd "$PNum($I) $MLoc($I) $Ib $Ic"
     }
     close $rFd
  }
}

