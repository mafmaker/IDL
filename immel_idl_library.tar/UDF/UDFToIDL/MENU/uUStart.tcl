proc uUStart { } {
   global env SyS EnV DbRead DbPaths tcl_platform Tasks TaskLabs \
          Task lineage PIDFRead PaGeS MaxPerPage UNumb UNumc PNum MLoc \
          DefMenu DefSs DefU DefDf DefAz DefTh DefAi

   set PIDFRead ""
   set DbRead  0
   set DbPaths 0
   set uEmpty  0
   set PaGeS   0
   set MaxPerPage  20
  

   set lineage [list PROJECT \
                     MISSION \
                     EXPERIMENT \
                     INSTRUMENT \
                     VIRTUAL ]

   set dU [list MINIMUM MAXIMUM] 
   set sS [list STANDARD COLLAPSE GROUP] 
   set dF [list FLOAT DOUBLE] 
   set nT [list ONCE/READ ONCE/DATA] 

   if [catch {set Dir [file join $env(UDFTOOL_HOME) GMenu] } OuT ] {
   } else { 
       set ProC [file join $Dir GSRC GM_PIDF.tcl] 
       if [file exists $ProC] { source $ProC }
       set ProC [file join $Dir GSRC GM_SysDeps.tcl] 
       if [file exists $ProC] { source $ProC }
   }

   GM_SysDeps

   if { [winfo exists .inTOP] == 0 } {
      wm title . "SELECT UNITS PACKAGE (PickUnits)"

      GM_Frame .inTOPa 
      GM_Frame .inTOPb 
      GM_Frame .inMAIN 
      GM_Frame .inMAIN.left
      GM_Frame .inMAIN.right

      pack  .inTOPa .inTOPb .inMAIN -side top -fill x
      pack  .inMAIN.left .inMAIN.right -side left -fill x

      uUPMEIVButtons

      set Wf ".inTOPa"
      set Wa1 $Wf.a
      set Wa2 $Wf.b
      set Wa3 $Wf.c
      GM_Button $Wa1 QUIT 1 0 false right exit 10
      GM_Button $Wa2 SAVE 1 0 false right uUSave 10
      GM_Button $Wa3 READ 1 0 false right uURdPidf 10

      set Wf ".inTOPb"
      set Wb1 $Wf.a
      set Wb2 $Wf.b
      set Wb3 $Wf.c
      set Wb4 $Wf.d
      set Wb5 $Wf.e
      set Wb6 $Wf.f
      GM_Frame $Wb1 0 
      GM_Frame $Wb2 0 
      GM_Frame $Wb3 0 
      GM_Frame $Wb4 0 
      GM_Frame $Wb5 0 
      GM_Frame $Wb6 0 
      pack  $Wb1 $Wb2 $Wb3 $Wb4 $Wb5 $Wb6 -side left -fill x

      GM_Label $Wb1.l "UNITS" 1 center false top
      set wD [uUSetWidth $dU]
      GM_MButton $Wb1.b "" 1 0 false bottom $dU "ProcOpts $Wb1.b" 10 1 $wD "" 1 
      GM_Label $Wb2.l "STORAGE" 1 center false top
      set wD [uUSetWidth $sS]
      GM_MButton $Wb2.b "" 1 0 false bottom $sS "ProcOpts $Wb2.b" 10 1 $wD "" 1
      GM_Label $Wb3.l "FORMAT" 1 center false top
      set wD [uUSetWidth $dF]
      GM_MButton $Wb3.b "" 1 0 false bottom $dF "ProcOpts $Wb3.b" 10 1 $wD "" 1
      GM_Label $Wb4.l "AZIMUTH" 1 center false top
      set wD [uUSetWidth $nT]
      GM_MButton $Wb4.b "" 1 0 false bottom $nT "ProcOpts $Wb4.b" 10 1 $wD "" 1
      GM_Label $Wb5.l "ELEVATION" 1 center false top
      GM_MButton $Wb5.b "" 1 0 false bottom $nT "ProcOpts $Wb5.b" 10 1 $wD "" 1
      GM_Label $Wb6.l "ARRAY INDICES" 1 center false top
      GM_MButton $Wb6.b "" 1 0 false bottom $nT "ProcOpts $Wb6.b" 10 1 $wD "" 1

      if {$DefMenu == 0 } {
         $Wb1.b configure -text [lindex $dU 0] -font default
         $Wb2.b configure -text [lindex $sS 0] -font default
         $Wb3.b configure -text [lindex $dF 0] -font default
         $Wb4.b configure -text [lindex $nT 0] -font default
         $Wb5.b configure -text [lindex $nT 0] -font default
         $Wb6.b configure -text [lindex $nT 0] -font default
      } else {
         $Wb1.b configure -text [lindex $dU $DefU] -font default
         $Wb2.b configure -text [lindex $sS $DefSs] -font default
         $Wb3.b configure -text [lindex $dF $DefDf] -font default
         $Wb4.b configure -text [lindex $nT $DefAz] -font default
         $Wb5.b configure -text [lindex $nT $DefTh] -font default
         $Wb6.b configure -text [lindex $nT $DefAi] -font default
      }

      if { $DefMenu == 1 } { uUFillIn }
   }
}

proc ProcOpts {W OPos} {
   set Lab [$W.menu entrycget $OPos -label]
   $W configure -text $Lab -font default
}
