#include <stdio.h>
#include <stdarg.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <math.h>

#include <export.h>

#include <libbase_udf.h>

#include "udfdlm_defs.h"
#include "udfdlm_ansi.h"

/**************\
|*  UDF_CLOSE  *|  Cleans up when done reading from a UDF
\**************/

PROCEDURE UDF_CLOSE( int Argc, IDL_VPTR Argv[], char *kw_unused )
{
   extern struct fh_cache fh_list[];
   extern void   *TmpSpace;
   extern void   *UDF;
   extern ByTe_4 TmpBytes;
  
   ByTe_4 FhNum;
   struct fh_cache *fh;
   struct Pidf         *P;

   if (Argc == 1) {
      FhNum = Argv[0]->value.i;
      fh = &fh_list[FhNum];
   } else
      IDL_Message(IDL_M_GENERIC, IDL_MSG_LONGJMP, "Usage: UDF_CLOSE, fh");

   if (fh->is_open == 1) {
      if (fh->dA != NULL)
         free (fh->dA);

      if (fh->Begs != NULL)
         free ((void *)fh->Begs);

      if (fh->AncInfo != NULL)
         free (fh->AncInfo);
         
      if (fh->Order != NULL)
         free(fh->Order);    

      if (fh->pInfo != NULL)
         free(fh->pInfo);    

      if (fh->sdef != NULL)
         free(fh->sdef);    

      P = (struct Pidf *)fh->PIDF;
      if (P->Groups != NULL)
         free (P->Groups);
      if (P->Units != NULL)
         free (P->Units);
      if (P->Sensors != NULL)
         free (P->Sensors);
      if (P->Scans != NULL)
         free (P->Scans);
      if (P->Ancil != NULL)
         free (P->Ancil);
      if (P->Modes != NULL)
         free (P->Modes);
      if (P->Bins != NULL)
         free (P->Bins);
      if (P->CMisc != NULL)
         free (P->CMisc);
      if (P->SMisc != NULL)
         free (P->SMisc);
      if (P->SMisc != NULL)
         free (P->SMisc);
      if (P->Pi.LatLong != NULL)
         free (P->Pi.LatLong);
      if (fh->PIDF != NULL)
         free (fh->PIDF);

      if (TmpSpace != NULL)
         free(TmpSpace);    

      fh->Order   = NULL;
      fh->Units   = NULL;
      fh->Dim     = NULL;
      fh->Loc     = NULL;
      fh->Set     = NULL;
      fh->uNDef   = NULL;
      fh->Begs    = NULL;
      fh->dA      = NULL;
      fh->AncInfo = NULL;
      fh->pInfo   = NULL;
      fh->PIDF    = NULL;
      TmpSpace    = NULL;
      TmpBytes    = 0;
      fh->is_open = 0;
      fh->tV      = 0;
      fh->Key     = 0;
      fh->flags.baseunit = 1;

      free_experiment_info();
      UDF = NULL;
   }
}
