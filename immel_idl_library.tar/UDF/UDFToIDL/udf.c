#include <stdio.h>
#include <stdarg.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <math.h>

#include <export.h>

#include <local_defs.h>
#include <user_defs.h>
#include <idf_defs.h>
#include <DbDefs.h>
#include <ret_codes.h>
#include <libbase_udf.h>
#include <PidfAnsi.h>
#include <PidfStr.h>
#include <PidfRets.h>
#include <libCfg.h>
#include <StrHier.h>
#include <dbf.h>

#include "udf.h"

/*
** Useful emit-error-and-exit routine
*/

void idl_barf( char *fmt, ... )
{
  va_list args;
  char    buf[1024];

  va_start(args, fmt);
  vsprintf(buf, fmt, args);

  IDL_Message(IDL_M_NAMED_GENERIC, IDL_MSG_LONGJMP, buf);
}


/*
** Garbage collection: IDL calls us when it's done with a data chunk.
**
** We could just make IDL call free(), but we'd get compiler warnings.
*/
void udf_free( UCHAR *ptr )
{
  free(ptr);
}
