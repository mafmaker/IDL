#include <stdio.h>
#include <stdarg.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <math.h>

#include <export.h>

#include <local_defs.h>
#include <user_defs.h>
#include <idf_defs.h>
#include <DbDefs.h>
#include <ret_codes.h>
#include <libbase_udf.h>
#include <PidfAnsi.h>
#include <PidfStr.h>
#include <PidfRets.h>
#include <libCfg.h>
#include <StrHier.h>
#include <dbf.h>

#include "udfdlm_defs.h"
#include "udfdlm_ansi.h"

void *MkDataStruc( struct fh_cache *fh)
{
   extern void     *UDF;
   extern IDL_LONG *TmpDim;
   extern int      ALIGN_MASK;
   extern u_ByTe_2 Version;
   extern ByTe_1   Ext[];
   extern ByTe_1   *TmpName;
   extern void     *TmpSpace;
   extern ByTe_4   TmpBytes;

   struct idf_data     *udf;
   struct Pidf         *P;
   struct PidfSensor   *Px;
   struct PidfMode     *Pm;
   struct PidfAnc      *Pa;

   ByTe_2              *s1;
   int                 nTag = 0;
   IDL_STRUCT_TAG_DEF  *TaGs;
   void                *retval;

   ByTe_4              L = 0, N, Dummy;
   ByTe_4              TotItems;
   ByTe_4              Dim[3];
   ByTe_4              B;
   u_ByTe_2 rV;

   ByTe_1              Name[1024];
   ByTe_1              Tname[1024];
   ByTe_1              *c1, *c2, **gn;

  /******************************************************************/
  /* Get the PIDF info for this key and establish some initial      */
  /* information from the PIDF                                      */
  /******************************************************************/

   ReadPidf (fh->Key, fh->PIDF);
   P = (struct Pidf *)fh->PIDF;
   Px = (struct PidfSensor *)P->Sensors;
   Pm = (struct PidfMode *)P->Modes;
   Pa = (struct PidfAnc *)P->Ancil;

  /******************************************************************/
  /* This is how to accumulate and output the sensor data           */      
  /******************************************************************/

   fh->sType = (fh->flags.dformat == 0) ? IDL_TYP_FLOAT : IDL_TYP_DOUBLE;

  /******************************************************************/
  /* First Cut at total items returned                              */
  /******************************************************************/

   fh->TotVSen = P->Ps.NSensors + CntExtra (fh, 'S');
   fh->TotAnc = P->Ps.NAncils + CntExtra (fh, 'A');
   fh->TotMode = P->Ps.NModes + CntExtra(fh, 'M');
   fh->TotIndex = (fh->sample_id != 2) ? 1 + CntExtra(fh, 'I') : 0;

  /******************************************************************/
  /* Establish enough space to set up the necessary information to  */
  /* identify what's to be returned.  We can set the Loc and Dim    */
  /* pointers at this time since they are fixed.                    */
  /******************************************************************/

   TotItems = fh->TotVSen + fh->TotAnc + fh->TotMode + fh->TotIndex;

   B = TotItems * (2 * sizeof(ByTe_2) + 4 * sizeof(ByTe_1));
   if ((fh->Order = (ByTe_2 *)malloc(B)) == NULL)
        idl_barf("make_idl_struct: malloc(Order)");

   fh->Units = fh->Order + TotItems;
   fh->uNDef = (ByTe_1 *)(fh->Units + TotItems);
   fh->Set = fh->uNDef + TotItems;
   fh->Loc = fh->Set + TotItems;
   fh->Dim = fh->Loc + TotItems;

  /********************************************************************/
  /* Count and tag the measurements in the PIDF Definitions and       */
  /* recalculate TotItems.  It might have shrunk                      */
  /********************************************************************/

   SetOrder (SENSOR, fh);
   SetOrder (ANCILLARY, fh);
   SetOrder (MODE, fh);
   SetOrder (SCAN_INDEX, fh);
   TotItems = fh->TotVSen + fh->TotAnc + fh->TotMode + fh->TotIndex;

   /*****************************************************************/
   /* Do all our pre mallocs here                                   */
   /*****************************************************************/

   B = (TotItems + MAX_TAGS) * sizeof(IDL_STRUCT_TAG_DEF);
   if ((TaGs = (IDL_STRUCT_TAG_DEF *)malloc(B)) == NULL)
        idl_barf("make_idl_struct: malloc(TaGs)");

   B = (TotItems + MAX_TAGS) * MAX_TAG_LEN;
   if ((TmpName = (ByTe_1 *)malloc(B)) == NULL)
        idl_barf("make_idl_struct: malloc(TmpName)");

   B = (TotItems + MAX_TAGS) * (4 * sizeof(long));
   if ((TmpDim = (IDL_LONG *)malloc(B)) == NULL)
        idl_barf("make_idl_struct: malloc(TmpDim)");

   B = (fh->TotAnc + MAX_BEGS) * sizeof(ByTe_4);
   if ((fh->Begs = (ByTe_4 *)malloc(B)) == NULL)
        idl_barf("make_idl_struct: malloc(fh->Begs)");

   B = (fh->sType == IDL_TYP_FLOAT) ? fh->maxlen * sizeof(ReaL_4) :
                                      fh->maxlen * sizeof(ReaL_8);
   if (B > TmpBytes) {
      TmpBytes = B;
      if ((TmpSpace = realloc(TmpSpace, B)) == NULL)
         idl_barf("make_idl_struct: realloc(TmpSpace)");
   }

  /*********BUG ALERT*******BUG ALERT*******BUG ALERT******BUG ALERT*******/
  /*                                                                      */
  /*  At this point the number of Columns in the data matrix is obtained. */
  /*  A value of 1 means not matrix data.  This value as far as I can see */
  /*  is obtained once!  Matrix sizes can change within a UDF file!       */
  /*  This does not seem to be taken into account!                        */
  /*                                                                      */
  /*********BUG ALERT*******BUG ALERT*******BUG ALERT******BUG ALERT*******/

   udf = (struct idf_data *)UDF;
   rV = read_drec(fh->Key, Ext, Version, UDF, -1, 0, 0, 0);
   if (rV != ALL_OKAY)
      udf_barf("read_drec", rV);

   fh->NCols = udf->TotCols;

  /**********************************************************************/
  /*  OK - NOW FOR THE STRUCTURE!                                       */
  /*                                                                    */
  /*  Always a start and a stop time and a length of data in sensor     */
  /**********************************************************************/

   Dim[0] = 0;
   Dim[1] = 0;
   Dim[2] = 0;
   Dummy = SetUpTag  (TaGs, "BTIME", UDF_TIME, Dim, nTag++);
   Dim[0] = 0;
   Dim[1] = 0;
   Dim[2] = 0;
   Dummy = SetUpTag (TaGs, "ETIME", UDF_TIME, Dim, nTag++);
   Dim[0] = 0;
   Dim[1] = 0;
   Dim[2] = 0;
   Dummy = SetUpTag (TaGs, "DLEN", IDL_TYP_LONG, Dim, nTag++);

  /**********************************************************************/
  /*  Always some data quality flags - but how many?                    */
  /*                                                                    */
  /*  One per sensor at least but if this is a matrix sensor then there */
  /*  is one per matrix column                                          */
  /**********************************************************************/
   fh->dSize = 0;

   SetDims (fh, Dim, 6, 0);
   fh->Begs[L++] = 0;
   fh->dSize += SetUpTag (TaGs, "D_QUAL", IDL_TYP_FLOAT, Dim, nTag++);

  /**********************************************************************/
  /*  Always some azimuth data, start and stop.  How many here depends  */
  /*  on how and if the keyword was set.  You get choices of 0) just    */
  /*  give it for the first sensor or 1) give it for all sensors.  In   */
  /*  the latter case you get it for all matrix elements if the data    */
  /*  is stored in matrix format.                                       */ 
  /**********************************************************************/

   PAD(fh->dSize, 4);
   fh->Begs[L++] = fh->dSize;
   SetDims (fh, Dim, 0, 0);
   fh->dSize += SetUpTag (TaGs, "START_AZ", IDL_TYP_FLOAT, Dim, nTag++);
   fh->Begs[L++] = fh->dSize;
   fh->dSize += SetUpTag (TaGs, "STOP_AZ", IDL_TYP_FLOAT, Dim, nTag++);

  /**********************************************************************/
  /*  Always some theta data, start and stop.  How many here depends    */
  /*  on how and if the keyword was set.  You get choices of 0) just    */
  /*  give it once per sensor or if matrix once per sensor per matrix   */
  /*  column;  1) give it for each element in the sensors and for       */
  /*  matrix data once for each matrix element.                         */
  /**********************************************************************/

   fh->Begs[L++] = fh->dSize;
   SetDims (fh, Dim, 1, 0);
   fh->dSize += SetUpTag (TaGs, "START_TH", IDL_TYP_FLOAT, Dim, nTag++);
   fh->Begs[L++] = fh->dSize;
   fh->dSize += SetUpTag (TaGs, "STOP_TH", IDL_TYP_FLOAT, Dim, nTag++);

  /**********************************************************************/
  /*  Throw in the array indices if this is an array or matrix UDF.     */
  /*  Same storage scheme as the azimuth data                           */
  /**********************************************************************/

   if (fh->sample_id != 2) {
      fh->Begs[L++] = fh->dSize;
      FillUnits (SCAN_INDEX, fh);
      SetDims (fh, Dim, 2, 0);
      c1 = fh->uNDef + fh->TotVSen + fh->TotAnc + fh->TotMode;
      for (N = 0; N < fh->TotIndex; ++N, ++c1)
      {
         if (*c1 == 0)
            sprintf (Name, "AINDICES");
         else
            sprintf (Name, "AINDICES_V%d",*c1);
         fh->dSize += SetUpTag(TaGs, Name, IDL_TYP_FLOAT, Dim, nTag++);
      }
   } else
      fh->Begs[L++] = -1;
 
  /**********************************************************************/
  /*  OK - now determine how we are going to save the science data.     */
  /**********************************************************************/

   if (fh->sType == IDL_TYP_DOUBLE)
       PAD(fh->dSize, 8);
   fh->Begs[L++] = fh->dSize;

  /**********************************************************************/
  /*  OK - create the data structures                                   */
  /**********************************************************************/

   FillUnits (SENSOR, fh);
   switch (fh->flags.sformat)
   {
      case 1:                                                /* GROUP */
        SetDims (fh, Dim, 5, N);
        fh->dSize += SetUpTag(TaGs, "ALLSDATA", fh->sType, Dim, nTag++);
      break;
      case 2:                                                /* GROUP */
        gn = (ByTe_1 **)P->Groups;
        s1 = fh->Order;
        c1 = fh->uNDef;
        for (N=0; N < P->Ps.NGroups; N++, ++c1) {
           SetDims (fh, Dim, 5, N);
           if (Dim[0] >= 0) {
              TagName (gn[N], Tname);
              sprintf (Name, "%s", Tname);
              fh->dSize += SetUpTag(TaGs, Name, fh->sType, Dim, nTag++);
           }
        }
      break;
      default:                                               /* STANDARD */
        SetDims (fh, Dim, 5, 0);
        s1 = fh->Order;
        c1 = fh->uNDef;
        for (N=0; N < fh->TotVSen; N++, ++c1) {
           TagName (Px[*s1++].Name, Tname);
           if (*c1 != 0)
              sprintf (Name, "%s_V%d",Tname, *c1);
           else
              sprintf (Name, "%s", Tname);
           fh->dSize += SetUpTag(TaGs, Name, fh->sType, Dim, nTag++);
        }
      break;
   }

  /**********************************************************************/
  /*  Next do modes if there are any around                             */
  /**********************************************************************/

   if (fh->TotMode > 0) {
      fh->Begs[L++] = fh->dSize;
      FillUnits (MODE, fh);
      SetDims (fh, Dim, 7, 0);
      s1 = fh->Order + fh->TotVSen + fh->TotAnc;
      c1 = fh->uNDef + fh->TotVSen + fh->TotAnc;
      for (N = 0; N < fh->TotMode; N++, ++c1) {
         TagName (Pm[*s1++].LDesc, Tname);
         if (*c1 != 0)
            sprintf (Name, "%s_V%d",Tname, *c1);
         else
            sprintf (Name, "%s", Tname);
         fh->dSize += SetUpTag(TaGs, Name, fh->sType, Dim, nTag++);
      } 
   } else
      fh->Begs[L++] = -1;
 
   
  /**********************************************************************/
  /*  And last try some ancillary data sets                             */
  /**********************************************************************/

   L = MAX_BEGS;
   if (fh->TotAnc > 0) {
      FillUnits (ANCILLARY, fh);
      s1 = fh->Order + fh->TotVSen;
      c1 = fh->uNDef + fh->TotVSen;
      c2 = fh->Loc + fh->TotVSen;
      for (N = 0; N < fh->TotAnc; N++, ++c1, ++c2) {
         fh->Begs[L++] = fh->dSize;
         Dim[0] = N;
         SetDims (fh, Dim, 8, 0);
         if (*c2 == 'S') 
            TagName (Px[*s1++].Name, Tname);
         else
            TagName (Pa[*s1++].LDesc, Tname);
         if (*c1 != 0)
            sprintf (Name, "%s_V%d",Tname, *c1);
         else
            sprintf (Name, "%s", Tname);
         fh->dSize += SetUpTag (TaGs, Name, fh->sType, Dim, nTag++);
      } 
   } else
      fh->Begs[L++] = -1;

   sprintf (Name, "%s_%d", fh->BaseName, fh->flags.sformat);

   /***********************************************************************/
   /*  Not sure why we need this extra pad but without it you can not do  */
   /*  multiple UDF_READS.  So for now it stays                           */
   /***********************************************************************/

   fh->dSize += 100;

   TaGs[nTag].name = 0;
   retval = IDL_MakeStruct(Name, TaGs);

   free (TaGs);
   free (TmpName);
   free (TmpDim);

   return retval;
}
