#include <stdio.h>
#include <stdarg.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <math.h>

#include <export.h>

#include "udfdlm_defs.h"
#include "udfdlm_ansi.h"

void SetBegs(struct fh_cache *fh, ByTe_4 *Begs)
{
}
