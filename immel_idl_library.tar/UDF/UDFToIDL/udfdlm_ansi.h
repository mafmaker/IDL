#ifndef	__UDF_DLM_ANSI_H
#define	__UDF_DLM_ANSI_H 1

#include "ByteDefs.h"
#include "udfdlm_str.h"
#include "PidfStr.h"

ByTe_4   CntExtra (struct fh_cache *, ByTe_1);
void     ConvAnc (struct fh_cache *, ByTe_1 *, ByTe_2, ByTe_2);
void     ConvIndex (struct fh_cache *, ByTe_1 *, ByTe_2, ByTe_2);
void     ConvMode(struct fh_cache *, ByTe_1 *);
void     ConvPhase (struct fh_cache *, ByTe_1 *, ByTe_2, ByTe_2);
void     ConvSensor (struct fh_cache *, ByTe_1 *, ByTe_2, ByTe_2);
void     ConvTheta (struct fh_cache *, ByTe_1 *, ByTe_2, ByTe_2);
void     CopyMem (ByTe_1 *, void *, ByTe_4, ByTe_1);
ByTe_1   FillUnits (ByTe_4,  struct fh_cache *);
ByTe_4   FindFh (u_ByTe_4);
int      ProcKeyWords (int, IDL_VPTR Argv[], char *); 
void     *MkDataStruc(struct fh_cache *);
void     idl_barf( char *, ... );
int      udf_to_idl_type( struct fh_cache *, ByTe_4);
int      udf_num_bytes( int);
void     udfdlm_get_date( IDL_VPTR, int *, int *, int *, int * );
void     udfdlm_time_fill( struct udf_time *, ByTe_4, ByTe_4, ByTe_4);
UCHAR    udfdlm_idl_fieldtype( ByTe_4, struct fh_cache *, ByTe_4);
void     udf_barf(ByTe_1 *, ByTe_2);
IDL_VPTR udf_pidf_c2idl( struct Pidf *);
char     *retcode_to_ascii( short);
void     idfs_error_message_str(ByTe_2, ByTe_1 *);
void     TagName( ByTe_1 *, ByTe_1 *);
u_ByTe_4 ReadOpts (ByTe_1 *);
ByTe_2   RetNumUnits (struct fh_cache *, ByTe_2, ByTe_1);
void     RetUnit (struct fh_cache *, ByTe_2, ByTe_1, ByTe_2 *, ByTe_2 *);
void     SetDims(struct fh_cache *, ByTe_4 *, ByTe_1, ByTe_4);
void     SetOrder(ByTe_2, struct fh_cache *);
ByTe_4   SetTrac(struct fh_cache *, ByTe_2, ByTe_2, ByTe_2, ByTe_2);
ByTe_4   SetUpTag(IDL_STRUCT_TAG_DEF *, ByTe_1 *, ByTe_4 , ByTe_4 *, ByTe_4);
ByTe_4   UdfAncSets(ByTe_2, struct fh_cache *, ByTe_2 *, ByTe_1 *);
void     UdfFree( UCHAR *);

#endif	/* __UDF_DLM_ANSI_H */
