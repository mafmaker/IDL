#include <stdio.h>
#include <stdarg.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <math.h>

#include <export.h>

#include <user_defs.h>
#include <ret_codes.h>
#include <libbase_udf.h>

#include "udfdlm_defs.h"
#include "udfdlm_ansi.h"

void ConvTheta (struct fh_cache *fh, ByTe_1 *Base, ByTe_2 N, ByTe_2 M)
{
   extern void *UDF;

   struct idf_data    *U;

   ByTe_4 TracOff;
   ByTe_4 NTheta;

   ByTe_1 *trac, Prec;


   U = (struct idf_data *)UDF;
   Prec = sizeof(ReaL_4);

   TracOff = SetTrac (fh, N, M, 0, 2);
   trac = Base + fh->Begs[3] + TracOff;
   NTheta = (fh->flags.theta == 0) ? 1 : U->num_sample;
   CopyMem (trac, U->start_theta, NTheta, Prec);
   trac = Base + fh->Begs[4] + TracOff;
   CopyMem (trac, U->stop_theta, NTheta, Prec);
}
