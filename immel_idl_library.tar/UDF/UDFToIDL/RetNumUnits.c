#include <stdio.h>
#include <stdarg.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <math.h>

#include <export.h>

#include "udfdlm_defs.h"
#include "udfdlm_ansi.h"

ByTe_2 RetNumUnits (struct fh_cache *fh, ByTe_2 Num, ByTe_1 Loc)
{
   register ByTe_4 *l1;
   register ByTe_2 *s1, *s2;
   register ByTe_1 *c1;

   ByTe_4 N, B, NUnits = 1;

   B = sizeof (ByTe_4);
   l1 = (ByTe_4 *)fh->pInfo;
   s1 = (ByTe_2 *)(fh->pInfo + fh->tV * B);
   B += sizeof (ByTe_2);
   s2 = (ByTe_2 *)(fh->pInfo + fh->tV * B);
   B += sizeof (ByTe_2);
   c1 = (ByTe_1 *)(fh->pInfo + fh->tV * B);

   for (N = 0; N < fh->tV; ++N, ++l1, ++s1, ++s2, ++c1) {
      if (*l1 == Num && *c1 == Loc) {
         NUnits = (*s1 == *s2) ? 1 : 2;
         break;
      }
   }

   return (NUnits);
}
