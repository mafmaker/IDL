#include <stdio.h>
#include <stdarg.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <math.h>

#include <export.h>

#include <local_defs.h>
#include <idf_defs.h>
#include <DbDefs.h>
#include <libCfg.h>
#include <PidfAnsi.h>
#include <PidfStr.h>
#include <PidfRets.h>
#include <user_defs.h>
#include <ret_codes.h>
#include <libbase_udf.h>

#include "udfdlm_defs.h"
#include "udfdlm_ansi.h"

/**************\
|*  UDF_OPEN  *|  Given a key, initializes access to UDF data
\**************/

FUNCTION UDF_OPEN(int Argc, IDL_VPTR Argv[], char *Argk)
{
   extern struct fh_cache fh_list[];
   extern ByTe_1 Ext[];
   extern u_ByTe_2 Version;
   extern LinkList Projects;
   extern void *UDF;

   struct Pidf         *P;

   ByTe_4    HH, MM, SS, B;
   StrHier   scode;
   ByTe_2    FieldId[5], *s1;
   ByTe_2    rV;
   u_ByTe_4  Key;
   ByTe_2    By, Bd, Ey, Ed;
   ByTe_4    Bs, Bns, Es, Ens;
   ByTe_4    fP;
   ByTe_1    NanC, *c1;

   IDL_VPTR  retval;

   struct fh_cache *fh;

  /************************************************************************/
  /* PROCESS Keywords before all else                                     */
  /************************************************************************/

   Argc = ProcKeyWords (Argc, Argv, Argk);

  /************************************************************************/
  /*  Calling Arguments:                                                  */
  /*                                                                      */
  /*  1.  Key - UDF Key                                                   */
  /*  2.  Beginning Year, Day, Hh, Mm, Ss Msec  - mandatory               */
  /*  3.  Ending Year, Day, Hh, Mm, Ss Msec  - optional                   */
  /*                                                                      */
  /*  If the ending time is omitted it is set to the end of the beginning */
  /*  day.                                                                */
  /************************************************************************/

  if (Argc < 2)
     IDL_Message(IDL_M_GENERIC, IDL_MSG_LONGJMP,
      "Usage:\n fh = UDF_OPEN(key, [BT], {[ET]})\n fh=UDF_OPEN(key, BT, {ET})");

  Key = Argv[0]->value.ul;

  if (Argv[1]->flags & IDL_V_NOT_SCALAR) {
     if (Argv[1]->value.arr->dim[0] < 2)
        idl_barf("UDF_OPEN: Must Have At Least BYear and BDay");

     s1 = (ByTe_2 *)Argv[1]->value.arr->data;
     By  = *s1++;
     Bd  = *s1++;
     HH  = (Argv[1]->value.arr->dim[0] > 2) ? *s1++ : 00;
     MM  = (Argv[1]->value.arr->dim[0] > 3) ? *s1++ : 00;
     SS  = (Argv[1]->value.arr->dim[0] > 4) ? *s1++ : 00;
     Bs =  3600 * HH + 60 * MM + SS;
     Bns = 0;

     if (Argc == 3) {
        s1 = (ByTe_2 *)Argv[2]->value.arr->data;
        Ey  = (Argv[2]->value.arr->dim[0] > 0) ? *s1++ : By;
        Ed  = (Argv[2]->value.arr->dim[0] > 1) ? *s1++ : Bd;
        HH  = (Argv[1]->value.arr->dim[0] > 2) ? *s1++ : 23;
        MM  = (Argv[1]->value.arr->dim[0] > 3) ? *s1++ : 59;
        SS  = (Argv[1]->value.arr->dim[0] > 4) ? *s1++ : 59;
        Es =  3600 * HH + 60 * MM + SS;
        Ens = 0;
     } else {
        Ey  = By;
        Ed  = Bd;
        HH  = 23;
        MM  = 59;
        SS  = 59;
        Es =  3600 * HH + 60 * MM + SS;
        Ens = 0;
     }
  } else {
     if (Argc < 3)
        idl_barf("UDF_OPEN: Must Have At Least BYear and BDay");
     By  = Argv[1]->value.ul;
     Bd  = Argv[2]->value.ul;
     HH  = (Argc > 3) ? Argv[3]->value.ul : 0;
     MM  = (Argc > 4) ? Argv[4]->value.ul : 0;
     SS  = (Argc > 5) ? Argv[5]->value.ul : 0;
     Bs =  3600 * HH + 60 * MM + SS;
     Bns = 0;

     Ey  = (Argc > 6) ? Argv[6]->value.ul : By;
     Ed  = (Argc > 7) ? Argv[7]->value.ul : Bd;
     HH  = (Argc > 8) ? Argv[8]->value.ul : 23;
     MM  = (Argc > 9) ? Argv[9]->value.ul : 59;
     SS  = (Argc > 10) ? Argv[10]->value.ul : 59;
     Es =  3600 * HH + 60 * MM + SS;
     Ens = 0;
  }

  /***********************/
  /* Get the filehandler */
  /***********************/

   fP = FindFh(Key);
   fh = &fh_list[fP];

  /*********************************************************************/
  /*  Open the Data files                                              */
  /*                                                                   */
  /* file_open is a safe call at anytime since it has its own built in */
  /* protection to prevent multiple opens.  If the file is open this   */
  /* routine will return doing nothing.  NOTE that with each call the  */
  /* expt begining times will be reset to those passed in              */ 
  /*********************************************************************/

   rV = file_open(Key, Ext, Version,
                  By, Bd, Bs, Bns,	/* Beginning time	    */
	          Ey, Ed, Es, Ens,	/* Ending time: forever     */
		  1);			/* 1 to be all encompassing */

   if (rV == NO_DATA || rV == EOF_STATUS)
      idl_barf("FileOpen: No Data For This Time Period");
   if (rV != ALL_OKAY)
      udf_barf("FileOpen", rV);

   fh->dSize = 0;

  /*************************************************************************/ 
  /* Collect the following VIDF info                                       */
  /*                                                                       */ 
  /*  1. max array size                                                    */
  /*  2. sensor type                                                       */
  /*  3. UDF timing format                                                 */
  /*  4. Number of ANC sets                                                */
  /*************************************************************************/ 

   rV = read_idf(Key, Ext, Version, (ByTe_1 *)&fh->maxlen, _SwpLeN,0,0,1);
   if (rV != ALL_OKAY)
      udf_barf("ReadIdf[MaxLen]", rV);


   rV = read_idf(Key, Ext, Version, (ByTe_1 *)&fh->sample_id, _SmpID, 0, 0, -1);
   if (rV != ALL_OKAY)
      udf_barf("ReadIdf[SampleId]", rV);

   if (fh->sample_id == 0) 
      fh->sample_id = 1;

   rV = read_idf(Key, Ext, Version, (ByTe_1 *)&fh->sen_mode, _SenModE, 0, 0, -1);
   if (rV != ALL_OKAY)
      udf_barf("ReadIdf[SenMode]", rV);

   rV = read_idf(Key, Ext, Version, &NanC, _CalSetS, 0, 0, -1);
   if (rV != ALL_OKAY)
      udf_barf("ReadIdf[AncSets]", rV);
   fh->nanc = NanC;

   if (NanC > 0) {
      B = NanC * (sizeof (ByTe_2) + sizeof(ByTe_1));
      if ((fh->AncInfo = malloc(B)) == NULL)
         idl_barf("UDF_OPEN: malloc(AncInfo) failed!");
      c1 = (ByTe_1 *)fh->AncInfo;
      rV = read_idf(Key, Ext, Version, c1, _CalUsE, 0, 0, -1);
      if (rV != ALL_OKAY)
         udf_barf("ReadIdf[AncUse]", rV);
      c1 = (ByTe_1 *)fh->AncInfo +  NanC * sizeof (ByTe_2);
      rV = read_idf(Key, Ext, Version, c1, _CalTargeT, 0, 0, -1);
      if (rV != ALL_OKAY)
         udf_barf("ReadIdf[AncTarget]", rV);
   } else
      fh->AncInfo = 0;

  /*************************************************************************/ 
  /* Get the PIDF info for this key and fill in a few parameters           */
  /*************************************************************************/ 

   ReadPidf (Key, fh->PIDF);
   P = (struct Pidf *)fh->PIDF;

  /*************************************************************************/ 
  /* Place file pointer to beginning time in the file according to how     */
  /* the PIDF blocking is set.                                             */
  /*************************************************************************/ 

   if (P->Pf.Blocking == 0)
      rV = file_pos(Key, Ext, Version, UDF, By, Bd, Bs, Bns, Ey, Ed, Es, Ens);
   else
      rV = FilePosRec(Key, Ext, Version, UDF, By, Bd, Bs, Bns, Ey, Ed, Es, Ens);

   if (rV != ALL_OKAY)
       udf_barf("FilePos", rV);

   /* Done!  Mark this spot as open */

   fh->is_open = 1;

  /************************************************************/ 
  /* Need to construct a unique structure name.               */
  /* To make it both unique and partially user friendly, it   */
  /* is formed as [VINST]_K[VALUE]_V[VALUE] where VINST is    */
  /* the UDF virtual acronym, the value following K is the    */
  /* UDF Key and the value following V is the version number  */
  /* associated with the key.                                 */
  /************************************************************/ 

   key_to_fields(fh->Key, FieldId);
   scode = SourceByNum(Projects, FieldId[0], FieldId[1], FieldId[2], 
		                 FieldId[3], FieldId[4], NULL);
   sprintf (fh->BaseName, "%s_K%d_V%d", SNAME(scode), fh->Key, Version);

  /**********************************************/ 
  /* Make IDL structures out of all this info   */
  /**********************************************/ 

   fh->sdef = MkDataStruc(fh);

   /* Remember the desired ending time, so we can check in UDF_EOF */

   fh->Ey  = Ey;
   fh->Ed  = Ed;
   fh->Ems = (Es * 1000) + (Ens / 1E6);

   retval          = IDL_Gettmp();
   retval->type    = IDL_TYP_INT;
   retval->value.i = fP;
   return retval;
}
