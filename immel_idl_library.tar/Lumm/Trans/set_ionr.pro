pro set_ionr_event, event

@common
@common_w

; the DONE button is the only one that can create an event.  Once an
; event is encountered, read the buttons and return to the main panel.

widget_control, b_zmax, get_value=zmax
widget_control, b_zmin, get_value=zmin
widget_control, b_npowers, get_value=npowers
ionr_param.yrange(0)=zmin
ionr_param.yrange(1)=zmax
ionr_param.npowers=npowers
widget_control, event.top, /destroy

return
end



pro set_ionr

@common
@common_w
@common_c

zmax=ionr_param.yrange(1)
zmin=ionr_param.yrange(0)
npowers=ionr_param.npowers

s1=widget_base(/column, title='Set Parameters', $
               xoffset=300, yoffset=200)
b_zmax=cw_field(s1, title='        zmax (km) =', value=zmax, /float)
b_zmin=cw_field(s1, title='        zmin (km) =', value=zmin, /float)
b_npowers=cw_field(s1, title='number of decades =', value=npowers, $
          /int)
                               
b_done=widget_button(s1, value='DONE')

widget_control, s1, /realize
xmanager, 'set_ionr', s1, group_leader=main_base, /modal

return
end
