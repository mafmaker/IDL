; Replace all these routines with their CDAWeb versions??
;-----------------------------------------------------------------------------

; Return the data for the given variable in the given structure
FUNCTION get_mydata_DEFUNCT,a,var
; Determine the variable number
s = size(var) & ns = n_elements(s) & atags = tag_names(a)
if s(ns-2) eq 7 then begin
  w = where(atags eq var,wc)
  if wc gt 0 then vnum = w(0) $
  else begin
    print,'ERROR>get_mydata:named variable not in structure!' & return,-1
  endelse
endif else vnum = var

; Retrieve the data for the variable
vtags = tag_names(a.(vnum))
ti = tagindex('HANDLE',vtags)
if ti ne -1 then handle_value,a.(vnum).handle,d $
else begin
  ti = tagindex('DAT',vtags)
  if ti ne -1 then d = a.(vnum).dat $
  else begin
    print,'ERROR>get_mydata:variable has neither HANDLE or DAT tag!' & return,-1
  endelse
endelse
d = reform(d)
return,d
end

;-----------------------------------------------------------------------------

; Return the idl sizing information for the data in the given variable
FUNCTION get_mydatasize, a, var
; Determine the variable number
s = size(var) & ns = n_elements(s) & atags = tag_names(a)
if s(ns-2) eq 7 then begin
  w = where(atags eq var,wc)
  if wc gt 0 then vnum = w(0) $
  else begin
    print,'ERROR>get_mydata:named variable not in structure!' & return,-1
  endelse
endif else vnum = var

; Retrieve the idl sizing information for the variable
vtags = tag_names(a.(vnum))
ti = tagindex('HANDLE',vtags) ; search for handle tag
if ti ne -1 then begin
  ti = tagindex('IDLSIZE',vtags) ; search for idlsize tag
  if ti ne -1 then isize = a.(vnum).IDLSIZE $
  else begin ; must retrieve data to get the size
    handle_value,a.(vnum).handle,d & isize = size(d)
  endelse
endif else begin ; search for dat tag
  ti = tagindex('DAT',vtags)
  if ti ne -1 then isize = size(a.(vnum).dat) $
  else begin
    print,'ERROR>get_mydata:variable has neither HANDLE or DAT tag!' & return,-1
  endelse
endelse

return,isize
end

;-----------------------------------------------------------------------------
; Modify the given tag (name or number) in the given variable (name or number)
; in the given structure 'a' with the new value.

FUNCTION modify_mystruct_DEFUNCT,a,var,tag,value
; Initialize
atags = tag_names(a)

; Determine the variable number and validate
s = size(var) & ns = n_elements(s)
if s(ns-2) eq 7 then begin ; variable is given as a variable name
  w = where(atags eq strupcase(var),wc)
  if wc gt 0 then vnum = w(0) $
  else begin
    print,'ERROR>modify_mystruct:named variable not in structure!' & return,-1
  endelse
endif else begin
  if ((var ge 0)AND(var lt n_elements(atags))) then vnum = var $
  else begin
    print,'ERROR>modify_mystruct:variable# not in structure!' & return,-1
  endelse
endelse
vtags = tag_names(a.(vnum))

; Determine the tag number and validate
s = size(tag) & ns = n_elements(s)
if s(ns-2) eq 7 then begin ; tag is given as a tag name
  w = where(vtags eq strupcase(tag),wc)
  if wc gt 0 then tnum = w(0) $
  else begin
    print,'ERROR>modify_mystruct:named tag not in structure!' & return,-1
  endelse
endif else begin
  if ((tag ge 0)AND(tag lt n_elements(vtags))) then tnum = tag $
  else begin
    print,'ERROR>modify_mystruct:tag# not in structure!' & return,-1
  endelse
endelse

; Create and return new structure with only the one field modified
for i=0,n_elements(atags)-1 do begin ; loop through every variable
  if (i ne vnum) then b = a.(i) $ ; no changes to this variable
  else begin ; must handle this variable field by field
    tnames = tag_names(a.(i))
    for j=0,n_elements(tnames)-1 do begin
      if (j ne tnum) then c = create_struct(tnames(j),a.(i).(j)) $ ; no changes
      else c = create_struct(tnames(j),value) ; new value for this field
      ; Add the structure 'c' to the substructure 'b'
      if (j eq 0) then b = c $ ; create initial structure
      else b = create_struct(b,c) ; append to existing structure
    endfor
  endelse
  ; Add the substructure 'b' to the megastructure
  if (i eq 0) then aa = create_struct(atags(i),b) $ create initial structure
  else begin ; append to existing structure
    c = create_struct(atags(i),b) & aa = create_struct(aa,c)
  endelse
endfor
return,aa
end

;-----------------------------------------------------------------------------

FUNCTION compare_vars_DEFUNCT, a, b

sa = size(a) & nsa = n_elements(sa)
sb = size(b) & nsb = n_elements(sb)
if (nsa ne nsb) then return,0
for i=0,nsa-1 do if (sa(i) ne sb(i)) then return,0

case sa(0) of
  0    : if (a ne b) then return,0
  1    : for i=0,sa(1)-1 do if (a(i) ne b(i)) then return,0
  2    : begin
         for i=0,sa(1)-1 do begin
           for j=0,sa(2)-1 do if (a(i,j) ne b(i,j)) then return,0
         endfor
         end
  else : print,'WARNING>cannot yet compare vars with > 2 dimensions!'
endcase

return,1
end

;-----------------------------------------------------------------------------
; Determine all information about the variable in the varstruct parameter,
; which is required in order to create the variable in a CDF file

FUNCTION create_myCDF_variable_DEFUNCT, id, varstruct, DEBUG=DEBUG
vid = -1
vname = varstruct.VARNAME ; Determine the name of the variable
; Determine IDL sizing information about the data
ti = tagindex('HANDLE',tag_names(varstruct))
if ti ne -1 then begin
  handle_value,varstruct.HANDLE,d & c = size(d)
endif else begin
  d = varstruct.DAT & c = size(d)
endelse
nc = n_elements(c)

; Determine if this variable is RV or NRV
nrv = 0L & rv = 0L ; initialize
ti = tagindex('VAR_TYPE',tag_names(varstruct))
if (ti ne -1) then begin ; var_type is present
  if (strupcase(varstruct.VAR_TYPE) eq 'METADATA') then nrv=1L else rv=1L
endif else rv=1L ; assume RV

; Determine the dimensionality and the data type based on record variance
if (rv eq 1L) then begin
  case c(0) of
    0   : print,'ERROR>size of data cannot be 0! - write_mycdf internal error'
    1   : begin & dims = 0L & dvar=[0] & end
    2   : begin & dims = c(1) & dvar=[1] & end
    3   : begin & dims = [c(1),c(2)] & dvar=[1,1] & end
    4   : begin & dims = [c(1),c(2),c(3)] & dvar=[1,1,1] & end
    else: print,'WARNING>cannot write cdfs with vars with > 3 dimensions!'
  endcase
endif
if (nrv eq 1L) then begin
  case c(0) of
    0   : print,'ERROR>size of data cannot be 0! - write_mycdf internal error'
    1   : begin & dims = c(1) & dvar=[1] & end
    2   : begin & dims = [c(1),c(2)] & dvar=[1,1] & end
    3   : begin & dims = [c(1),c(2),c(3)] & dvar=[1,1,1] & end
    else: print,'WARNING>cannot write cdfs with vars with > 3 dimensions!'
  endcase
endif

; Determine the type of the CDF variable
dtype = lonarr(14) & nelems=1L ; initialize
case c(nc-2) of
  0   : print,'ERROR>Undefined data type'
  1   : dtype(0) = 1L ; cdf_byte
  2   : dtype(6) = 1L ; cdf_int2
  3   : dtype(7) = 1L ; cdf_int4
  4   : dtype(8) = 1L ; cdf_real4
  5   : begin ; determine if it is real8 or epoch
          if varstruct.CDFTYPE eq 'CDF_EPOCH' then dtype(3) = 1L $
          else dtype(9) = 1L ; cdf_real8
        end
  6   : print,'WARNING>CDF does not have complex_float type'
  7   : begin ; cdf_char
          dtype(1) = 1L
          nelems = strlen(d(0))
        end
  8   : print,'WARNING>CDF does not have structure type'
  9   : print,'WARNING>CDF does not have double_complex_float type'
  else: print,'ERROR>Unknown IDL data type'
endcase

; Create the variable
if keyword_set(DEBUG) then begin
  print,'creating the variable:',vname
  print,'rv=  ',rv,  ' nrv=  ',nrv,' nelems=',nelems
  print,'dims=',dims,' dvary=',dvar
endif
if (dims(0) eq 0) then begin
  vid = cdf_varcreate(id,vname,/ZVARIABLE,NUMELEM=nelems,$
        CDF_BYTE=dtype(0),CDF_CHAR=dtype(1),CDF_DOUBLE=dtype(2),$
        CDF_EPOCH=dtype(3),CDF_FLOAT=dtype(4),CDF_INT1=dtype(5),$
        CDF_INT2=dtype(6),CDF_INT4=dtype(7),CDF_REAL4=dtype(8),$
        CDF_REAL8=dtype(9),CDF_UCHAR=dtype(10),CDF_UINT1=dtype(11),$
        CDF_UINT2=dtype(12),CDF_UINT4=dtype(13),$
        REC_NOVARY=nrv,REC_VARY=rv)
endif else begin
  vid = cdf_varcreate(id,vname,dvar,DIMENSIONS=dims,NUMELEM=nelems,$
        CDF_BYTE=dtype(0),CDF_CHAR=dtype(1),CDF_DOUBLE=dtype(2),$
        CDF_EPOCH=dtype(3),CDF_FLOAT=dtype(4),CDF_INT1=dtype(5),$
        CDF_INT2=dtype(6),CDF_INT4=dtype(7),CDF_REAL4=dtype(8),$
        CDF_REAL8=dtype(9),CDF_UCHAR=dtype(10),CDF_UINT1=dtype(11),$
        CDF_UINT2=dtype(12),CDF_UINT4=dtype(13),$
        REC_NOVARY=nrv,REC_VARY=rv)
endelse

; write the data into the cdf with special handling for character data
if c(nc-2) ne 7 then cdf_varput,id,vname,d $
else begin ; special processing for character data
  if ((c(0) eq 0)AND(d(0) ne '')) then cdf_varput,id,vname,d $
  else begin ; data is a string array
    ; pad all elements to same length and concatenate into single buffer
    maxlength = max(strlen(d)) & buffer = ''
    for j=0,c(1)-1 do begin
      if strlen(d(j)) eq maxlength then buffer = buffer + d(j) $
      else begin
        pad = '' & for g=0,(strlen(d(j))-maxlength)-1 do pad = pad + ' '
        buffer = buffer + d(j) + pad
      endelse
    endfor
    cdf_varput,id,vname,buffer,OFFSET=[0],COUNT=[c(1)]
  endelse
endelse

return,vid
end

;-----------------------------------------------------------------------------

; This package of routines complements the read_myCDF package.  read_myCDF
; reads one or more cdf's, and returns all data and metadata as a single
; structure.  write_myCDF will do just the opposite, given a similar structure,
; it will write a cdf.

function cdfx_write_myCDF, a, filename, DEBUG=DEBUG

; Identify the global attributes.
b = tag_names(a.(0)) & w = where(b eq 'FIELDNAM',wc) & gattrs=indgen(w(0)-1)+1

; Determine the order of the variables to be written to the CDF.
b = tag_names(a) & nb = n_elements(b) & c = intarr(nb)
for i=0,nb-1 do begin
  if a.(i).CDFTYPE eq 'CDF_EPOCH' then c(i) = 2 $ ; time variable
  else if strupcase(a.(i).VAR_TYPE) eq 'DATA' then c(i) = 1 ; RV variable
endfor
s=sort(c) & d=indgen(nb) & order=d(reverse(s))

; Create the new CDF
if keyword_set(DEBUG) then print,'Now creating the CDF...'
id = cdf_create(filename,/NETWORK_ENCODING,/SINGLE_FILE)

; Write global attributes to the CDF
if keyword_set(DEBUG) then print,'Writing global attributes to the CDF...'
b = tag_names(a.(0)) ; get names of attributes
for i=0,n_elements(gattrs)-1 do begin
  aid = cdf_attcreate(id,b(gattrs(i)),/GLOBAL_SCOPE) ; create the attribute
  ; Now put the proper value in the attribute
  s = size(a.(0).(gattrs(i))) & ns = n_elements(s) & c=''
  if (s(ns-2) eq 7) then begin ; special case for string handling
    if s(0) eq 0 then begin
      c = a.(0).(gattrs(i)) & if c ne '' then cdf_attput,id,aid,0L,c
    endif else begin
      for j=0,s(1)-1 do begin
        c = a.(0).(gattrs(i))(j) & cdf_attput,id,aid,j,c
      endfor
    endelse
  endif else cdf_attput,id,aid,0L,a.(0).(gattrs(i))
endfor

; Create the variables
for i=0,n_elements(order)-1 do begin
  b = order(i) & vname = a.(b).VARNAME
  if keyword_set(DEBUG) then print,'Creating the variable:',vname
  vid = create_myCDF_variable(id, a.(b))
endfor ; create and write all variables


; Write the variable attributes to the CDF
for i=0,n_elements(tag_names(a))-1 do begin ; loop through every variable
  vname = a.(i).VARNAME ; get the case sensitive variable name
  vtags = tag_names(a.(i)) ; get the attribute names
  from = tagindex('FIELDNAM',vtags) ; fieldnam is the first vattr
  to   = tagindex('CDFTYPE' ,vtags) ; cdftype is the next non-vattr
  for j=from,to-1 do begin ; process each variable attribute
    if i eq 0 then aid = cdf_attcreate(id,vtags(j),/VARIABLE_SCOPE) $
    else aid = cdf_attnum(id,vtags(j)) ; get id of existing attribute
    ; Special processing is required for ISTP-stype pointer attributes.
    ; If the current attribute is such an attribute, do not process it here.
    if (amI_ISTPptr(vtags(j)) ne 1) then begin
      s = size(a.(i).(j)) & ns = n_elements(s)
      if (s(ns-2) ne 7) then cdf_attput,id,aid,vname,a.(i).(j) $
      else begin ; special processing for character data
        if s(0) eq 0 then begin
          e = a.(i).(j) & if e ne '' then cdf_attput,id,aid,vname,e
        endif else begin ; data is a string array
          print,'WARNING: ',vtags(j),' vattr not written because of IDL bug!'
        endelse
      endelse
    endif
    endfor
endfor

; Perform special processing for ISTP pointer-type attributes.  When such an
; attribute is located, a new metadata variable may have to be created.
mvcount = 0L
for i=0,n_elements(tag_names(a))-1 do begin ; loop through every variable
  vtags = tag_names(a.(i)) ; get the name of every attribute
  for j=0,n_elements(vtags)-1 do begin
    if ((amI_ISTPptr(vtags(j)) eq 1)AND(a.(i).(j)(0) ne '')) then begin

      pvar = -1 ; determine if identical value has already been encountered
      for g=0,mvcount-1 do begin
        if compare_vars(a.(i).(j),a.(pv(g)).(pt(g))) eq 1 then pvar = g ; same
      endfor

      if (pvar eq -1) then begin ; MUST CREATE NEW VARIABLE
        ; determine the name for new variable
        vname = 'metavar' + strtrim(string(mvcount),2)
        ; create a variable structure
        va = create_struct('VARNAME',vname)
        vb = create_struct('VAR_TYPE','metadata')
        vc = create_struct('DAT',a.(i).(j))
        v  = create_struct(va,vb) & v = create_struct(v,vc)
        ; create the new variable in the CDF
        vid = create_myCDF_variable(id, v)
        cdf_attput,id,'VAR_TYPE',vname,'metadata'
        cdf_attput,id,'FIELDNAM',vname,vname
      endif else vname = a.(pvar).VARNAME

      ; point to the new variable via the istp pointer attribute
      cdf_attput,id,vtags(j),a.(i).VARNAME,vname

      ; record the variable number and tag number of this attribute
      if mvcount eq 0 then begin
        pv = i & pt = j
      endif else begin
        pv = [pv,i] & pt = [pt,j]
      endelse
      mvcount = mvcount + 1 ; increment metavariable count
    endif
  endfor
endfor

; Close the new CDF
cdf_close,id

return,0
end

;-----------------------------------------------------------------------------
