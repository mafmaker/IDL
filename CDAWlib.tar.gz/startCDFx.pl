#!/usr/local/bin/perl.5 -w
$cdfplot_dir = $ENV{'CDFPLOT_DIR'};
$outFileName = "$cdfplot_dir/startCDFx.pro";
$ENV{'IDL_STARTUP'} = "";
$cmd = "idl $outFileName";
system($cmd);
