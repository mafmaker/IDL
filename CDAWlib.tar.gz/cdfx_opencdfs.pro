;-----------------------------------------------------------------------------
; Returns true if either (A) the passed set of two strings are valid time
; specifications for 'read_myCDF', or (B) both strings are empty.

function cdfx_valid_time_range, tr

syntax = '[0-9]{4}(/[0-9]{2}){2} [0-9]{2}(:[0-9]{2}){2}'

return, (tr[0]+tr[1] eq '') or $
  (stregex(tr[0], syntax, /boolean) and stregex(tr[1], syntax, /boolean))
end

;-----------------------------------------------------------------------------
; Returns the named attribute of a given variable of a given CDF object.

function cdfx_read_attr, cdfid, varname, attname

;attname = strupcase(attname)

error_status = 0    ; initialize error flag
catch, error_status ; set up exception handler to handle missing name
if error_status ne 0 then $
  return, '' $
else $
  a = read_myattribute(varname, cdf_attnum(cdfid, attname), cdfid)

return, a.(0)
end

;-----------------------------------------------------------------------------
; Returns the minimum and maximum epoch values of the given CDF data files.

function cdfx_time_range_of_files, fpaths

for i = 0, n_elements(fpaths)-1 do begin
  fpath = fpaths[i]
  cdfid = cdf_open(fpath)

  epoch = read_myvariable('Epoch', cdfid, vary, dtype, recs)
  emin = epoch[0]
  emax = epoch[n_elements(epoch)-1]

  if i eq 0 then begin
    tmin = emin
    tmax = emax
  endif else begin
    tmin = min([tmin, emin])
    tmax = max([tmax, emax])
  endelse

  cdf_close, cdfid
endfor

return, [tmin, tmax]
end

;-----------------------------------------------------------------------------
; Separates a list of CDF file paths into ordinary data files and
; master files.  Also supplements the master file set with new ones
; generated from the data file names, looking for masters in both the
; current directory and the user-specified Masters directory.

pro cdfx_separate_cdfs, fpaths, cpaths=cpaths, mpaths=mpaths

common cdfxcom, CDFxwindows, CDFxprefs ; include cdfx common

cpaths = ['']
mpaths = ['']

for i = 0, n_elements(fpaths)-1 do begin
  fpath = fpaths[i]

  if not stregex(fpath, '.*_00000000_.*cdf$', /boolean) then begin
    cpaths = [cpaths, fpath]

    ;dname = stregex(path, '/.*/', /extract)
    fname = stregex(fpath, '[^/]+$', /extract)
    split = strsplit(fname, '_', /extract)
    split[3] = '00000000'
    split[4] = 'v01.cdf'  ;always version 1??
    mname = strjoin(split, '_', /single)
    fpath = findfile("{.," + CDFxprefs.masters_path + "}/" + mname)
  endif

  mpaths = [mpaths, fpath]
endfor

if n_elements(cpaths) gt 1 then $
  cpaths = cpaths[1:*]

if n_elements(mpaths) gt 1 then $
  mpaths = cdfx_uniq_sort(mpaths[1:*])

end

;-----------------------------------------------------------------------------
; Returns whether the given set of CDF data files are structurally
; compatible with each other.  Compatibility is defined by the routine
; Compare_mycdfs.

function cdfx_files_compatible, cpaths

n = n_elements(cpaths)
if n lt 2 then return, 1

id0 = cdf_open(cpaths[0])

for i = 1, n-1 do begin
  id = cdf_open(cpaths[i])
  match = compare_mycdfs(id, id0)
  cdf_close, id

  if not match then begin
    cdf_close, id0
    return, 0
  endif  
endfor

cdf_close, id0
return, 1
end

;-----------------------------------------------------------------------------

pro cdfx_refine_open_event, event

widget_control, event.top, get_uvalue=info
widget_control, (*info).list, get_value=bvals

case event.id of
  (*info).bSelectAll:	begin
	bvals[*] = 1
	widget_control, (*info).list, set_value=bvals
	end

  (*info).bUnselectAll:	begin
	bvals[*] = 0
	widget_control, (*info).list, set_value=bvals
	end

  (*info).bCancel:	begin
	widget_control, event.top, /destroy
	end

  (*info).bProceed:	begin
        widget_control, (*info).tstart, get_value=tstart
        widget_control, (*info).tstop,  get_value=tstop
	trange = [tstart[0], tstop[0]]
	w = where(bvals eq 1, wc)

	if not cdfx_valid_time_range(trange) then $
	  resp = widget_message(/error, "Invalid syntax in time fields!") $
	else if wc lt 1 then $
	  resp = widget_message(/error, 'No variables selected!') $
	else begin
	  (*info).selection = bvals
	  (*info).trange = trange
	  widget_control, event.top, /destroy
	endelse

	end

  else : ; do nothing
endcase

end

;-----------------------------------------------------------------------------

function cdfx_opencdfs

;common cdfxcom, CDFxwindows, CDFxprefs ; include cdfx common

; Get a set of CDF files from user.
paths = dialog_pickfile(title='Choose CDF(s)', filter="*.cdf", $
  /multiple)  ;/fix_filter
if paths[0] eq '' then return, -1

cdfx_separate_cdfs, paths, cpaths=cpaths, mpaths=mpaths

if n_elements(cpaths) lt 1 then begin
  resp = widget_message(/error, 'No CDF data files selected!')
  return, -1
endif

if not cdfx_files_compatible(cpaths) then begin
  resp = widget_message(/error, $
    'The selected data files are not structurally compatible!')
  return, -1
endif

if n_elements(mpaths) lt 1 then $
  resp = widget_message(/warning, 'No CDF master files found.')

mcdfid = cdf_open(mpaths[0])
cdfid  = cdf_open(cpaths[0])
;cinfo  = cdf_inquire(cdfid) ; inquire about the cdf
vnames = cdfx_uniq_sort([get_allvarnames(cdfid=mcdfid), $
  get_allvarnames(cdfid=cdfid)])
nvars  = n_elements(vnames)
vlist  = strarr(nvars)

; Gather display information for the variables.

for i=0, nvars-1 do begin ; construct the list of variables name
  vname = vnames[i]

  vtype = cdfx_read_attr(cdfid, vname, 'VAR_TYPE')
  if vtype eq '' then $
    vtype = cdfx_read_attr(mcdfid, vname, 'VAR_TYPE')

  fname = cdfx_read_attr(cdfid, vname, 'FIELDNAM')
  if fname eq '' then $
    fname = cdfx_read_attr(mcdfid, vname, 'FIELDNAM') + ' (M)'

  if vtype eq 'data'  or  vtype eq 'support_data' then $
    vlist[i] = string(format='(a25,a15,a50)', vname, vtype, fname)

endfor

; Filter out variables that aren't 'data' or 'support_data'.

w = where(vlist ne '', wc)
if wc lt 1 then begin
  resp = widget_message(/error, $
    'No data or support data variables found!')
  return, -1
endif

vlist = vlist[w]
nvars = n_elements(vlist)
cdf_close, cdfid
cdf_close, mcdfid

trange = cdfx_time_range_of_files(cpaths)
tstart = cdfx_time_string_of_epoch(trange[0])
tstop  = cdfx_time_string_of_epoch(trange[1])

base	= widget_base(/column, title='Select Variables and Time Interval', /frame)
base1	= widget_base(base, /column, /frame)
base3	= widget_base(base, /row)
base4	= widget_base(base3, /column, /frame)
base2	= widget_base(base3, /column, /frame)

w	= widget_label(base4, value='Time Interval')
w	= widget_label(base4, value='(Format: YYYY/MM/DD hh:mm:ss)')
bstart	= widget_base(base4, /row)
lstart	= widget_label(bstart, value='Start time:')
bstop	= widget_base(base4, /row)
lstop	= widget_label(bstop, value='Stop time: ')

info = ptr_new({$
  selection:lonarr(nvars), $
  trange:["",""], $
  list:cw_bgroup(base1, vlist, /nonexclusive, scroll=(nvars>20), $
    set_value = lonarr(nvars), $
    label_top = strtrim(string(nvars), 2) + ' Variables', $
    y_scroll = (20 * !d.y_ch_size), $
    x_scroll = (95 * !d.x_ch_size)), $
  tStart:	widget_text(bstart, value=tstart, xsize=20, /editable), $
  tStop:	widget_text(bstop , value=tstop , xsize=20, /editable), $
  bProceed:	widget_button(base2, value='Proceed'), $
  bSelectAll:	widget_button(base2, value='Select All'), $
  bUnselectAll:	widget_button(base2, value='Unselect All'), $
  bCancel:	widget_button(base2, value='Cancel') })

widget_control, base, /realize, set_uvalue=info
xmanager, 'cdfx_refine_open', base, /modal

w = where((*info).selection eq 1, wc)
a = -1
if wc gt 0 then begin
  tstart = ((*info).trange)[0]
  tstop  = ((*info).trange)[1]
  widget_control, /hourglass

  if tstart eq "" or tstop eq "" then begin
    a = read_mycdf(vnames[w], [mpaths, cpaths], /nodatastruct)
  endif else begin
    a = read_mycdf(vnames[w], [mpaths, cpaths], /nodatastruct, $
      tstart=tstart, tstop=tstop)
  endelse
endif

ptr_free, info
return, a
end

;-----------------------------------------------------------------------------
