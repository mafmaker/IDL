@compile_cdaweb

.compile cdfx_utils
.compile cdfx_prefs
.compile cdfx_windowlist
.compile cdfx_opencdfs
.compile cdfx_timeslice
.compile cdfx_editvattrs
.compile cdfx_showstats

;---- CDAWeb already has these routines!
.compile cdfx_writemycdf

.compile cdfx_xinteranimate
@compile_xreadmycdf
.compile cdfx2

;save, filename='cdfx.sav', /routines
;cdfx
