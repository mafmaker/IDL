;$Author: mathews $
;$Date: 2003/10/22 12:01:42 $
;$Revision: 1.1 $
; This file contains a utility function to return the date of the last
; modification to the library.

function version
    return, 'CDAWeb library last revised on Wed Oct 22 12:01:42 2003'
end
